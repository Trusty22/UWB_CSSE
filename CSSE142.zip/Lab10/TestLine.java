
/**
 * Write a description of class TestLine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestLine
{
    public static void main(String[] args){
        
        LineAtOfficeHour line = new LineAtOfficeHour();
    
        Student jeff = new Student();
        jeff.setFirst("jeff");
        jeff.setLast("brown");
        line.enterLine(jeff);
        
        Student nick = new Student();
        nick.setFirst("nick");
        nick.setLast("robinson");
        line.enterLine(nick);
        
        Student joe = new Student();
        joe.setFirst("joe");
        joe.setLast("ranch");
        line.enterLine(joe);
        
        Student mandeep = new Student();
        mandeep.setFirst("mandeep");
        mandeep.setLast("masoun");
        line.enterLine(mandeep);
        
        Student appleMan = new Student();
        appleMan.setFirst("Apple");
        appleMan.setLast("Man");
        line.enterLine(appleMan);
        
        line.whosInLine();
        
        System.out.println("The line is Empty? = " + line.isEmpty());
        System.out.println("The full is Empty? = " +line.isFull());
        System.out.println("The size of the line is "+line.size());
        System.out.println(line.seeTeacher().fullName() + " has to see the teacher");
        
        line.whosInLine();
    }
}
