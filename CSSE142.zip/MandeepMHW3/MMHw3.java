import java.util.*;
/**
 * Write a description of class MMHw3 here.
 * *By Mandeep Masoun
 * Prof Hansel Ong
 * Apr 24 2022
 * 
 * Hw 3 is the final part about understanding the inflation in america,
 * so this program warpas that up.
 * 
 * We go through a series of commands that prompt us to either, 
 * add an item name, add inflation, add price, then we go through loops and methods that
 * increase our price due to inflation. We show this through budget analysis and 
 * cost increase,
 * 
 * key: 
 * analy = anlalysis
 * proj = projected
 * infl = inflation
 */
public class MMHw3
{ 
    public static String item = "cake";
    public static double price = 10.0;
    public static double infl = 1.0;
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        boolean repeat = true;
        int input;
        
        while(true){
            mainMenu();
            input = sc.nextInt();

            options(input, sc);
            //System.out.println(item+" "+price+" "+infl);
        }
    }
    //Cost of item(s)? $
    public static void options(int input, Scanner sc){
        if(input == 1){
            item = itemName(sc);
        } else if(input == 2){
            price = itemCost(sc);
        }else if(input == 3){
            infl = inflRate(sc);
        }else if(input == 4){
            analysis(sc);
        }else if(input == 5){
            System.out.println("\nThanks for using our program!");
            System.exit(0);
        } else{
            invalid(sc);      
        }
    }
    
    public static void analysis(Scanner sc){
        int input;
        analyMenu();
        input = sc.nextInt();
        
        analyOptions(input, sc);
    }
    //finish options for analyisis
    public static void analyOptions(int input, Scanner sc){
        if(input == 1){
            bugetAnaly(sc);
        } else if(input == 2){
            projCost(sc);
        }else{
            analyInvalid(sc);
        }
    }
    
    public static void bugetAnaly(Scanner sc){
         int years;
         double budget;
         
         System.out.println("How many years of analysis would you like? ");
         years = sc.nextInt();
         
        while(years > 10 || years <= 0){
            System.out.println("Input Invalid: must be between 1 and 10 years (inclusive)");
            System.out.print("How many years of analysis would you like? ");
            years = sc.nextInt();

        }
         
         System.out.print("What is your budget? $");
         budget = sc.nextDouble();
         printAmount(years,budget);
         
    }
    
    public static void projCost(Scanner sc){
        int years;
        System.out.println("How many years of analysis would you like? ");
        years = sc.nextInt();
            while(years > 30 || years <= 0){
            System.out.print("Input Invalid: must be between 1 and 30 years (inclusive)");
            System.out.print("How many years of analysis would you like? ");
            years = sc.nextInt();

        } 
        printAnaly(years);
        
    }
    
    public static void printAnaly(int year){
        double newPrice = price;
        for(int i = 0; i < year; i++){
            System.out.printf("Year " + (2021 + i + 1) 
            + ", projected cost is $%.2f\n", newPrice);
            
            newPrice = increasePrice(infl/100,newPrice);
            
        }
    }
    
    public static void printAmount(int year, double budget){
        double affordablity = (budget/price);
        double newPrice = price;
        for(int i = 0; i < year; i++){
            System.out.println("Year " + (2021 + i + 1) 
            + ", you can afford "+ (int)(affordablity) + " "+item);
            
            newPrice = increasePrice((infl/100.0), newPrice);
            affordablity = budget/(newPrice);
            
        }
         
    }
    
     public static double increasePrice(double inf, double cost){
        double newCost =  (cost + (cost * inf));
        return newCost;
    }
    
        public static String itemName(Scanner sc){
        String item;
        
        System.out.println("Item Name?");
        item = sc.next();        
        while(item.length() < 3){
            System.out.println("Invalid name; must be at least two characters long!");
            
            System.out.println("Item Name?");
            item = sc.next();     
           
        }
        return item;
    }
    
    public static double itemCost(Scanner sc){
        double cost = 0;
        
        System.out.print("Cost of item(s)? $");
        cost = sc.nextDouble();        
        
        return cost;
    }
    
    public static double inflRate(Scanner sc){
        double rate = 1.0;
        
        System.out.println("Average annual inflation rate?");
        rate = sc.nextDouble();  
        while(rate < 0 || rate > 4.9){
            System.out.println("Invalid inflation rate; must be between 0 and 4.9% inclusive");
            
            System.out.println("Average annual inflation rate?");
            rate = sc.nextDouble();         
        }
        return rate;
    }
    
    public static void analyInvalid(Scanner sc){
        System.out.println("Invalid option!  Please try again!");
        analyMenu();
        int input = (sc.nextInt());
        analyOptions(input,sc);         
    }
    
    public static void invalid(Scanner sc){
        System.out.println("Invalid option!  Please try again!");
        mainMenu();
        int input = (sc.nextInt());
        options(input,sc);         
    }

    public static void analyMenu(){
        System.out.println("Please choose from the following options:\n"+
                           "1. Budget Analysis\n"+
                           "2. Cost Increase");
    }
    
    public static void mainMenu(){
        System.out.println("Please choose from the following options:\n"+
            "1. Enter/Update Item Name\n"+
            "2. Enter/Update Item Cost\n"+
            "3. Enter/Update average inflation rate\n"+
            "4. Display Analysis\n"+
            "5. Exit Program");
    }
}