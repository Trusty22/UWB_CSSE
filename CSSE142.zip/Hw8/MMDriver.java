import java.util.*;
/**
 * Write a description of class MMDriver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MMDriver
{
    public static void main(String args[]){
        positive();
        negitive();
        boundery();
    }
    public static void positive(){
        String[][] list = new String[2][10];
        
        list[0][0] = "Height";
        list[1][0] = "6 INCH";
        
        list[0][1] = "Weight";
        list[1][1] = ".25 LB";
        
        list[0][2] = "Color";
        list[1][2] = "red";
        
        //System.out.println(Arrays.deepToString(list));
        
        MMDevice Iphone = new MMDevice("Iphone");
        MMDevice Samsung = new MMDevice("Samsung", list);
        
        Iphone.addFeature("Length", "2 Inches");
        Iphone.showFeatures();
        
    }
    public static void negitive(){
        String[][] list = new String[2][10];
        
        list[0][0] = "Hght";
        list[1][0] = "6 INCH";
        
        list[0][1] = "Weiht";
        list[1][1] = ".25 LB";
        
        list[0][2] = "Coor";
        list[1][2] = "red";
        
        //System.out.println(Arrays.deepToString(list));
        
        MMDevice Iphone = new MMDevice("I");
        MMDevice Samsung = new MMDevice("S", list);
        
        Iphone.addFeature("Height", "6 INCH");
        Iphone.showFeatures();
        
    }
    public static void boundery(){
        String[][] list = new String[2][10];
        
        list[0][0] = "Height";
        list[1][0] = "6 INCH";
        
        list[0][1] = "Weight";
        list[1][1] = ".25 LB";
        
        list[0][2] = "Color";
        list[1][2] = "red";
        
         list[0][3] = "Length";
        list[1][3] = "6 INCH";
        
        list[0][4] = "Volume";
        list[1][4] = " 30 cm^3";
        
        list[0][5] = "Width";
        list[1][5] = "3 Inch";
        
        list[0][6] = "Wifi";
        list[1][6] = "Yes";
        
        list[0][7] = "Bluetooth";
        list[1][7] = "No";
        
        list[0][8] = "Camera";
        list[1][8] = "Yes";
        
         list[0][9] = "Buttons";
        list[1][9] = "No";
        
        //System.out.println(Arrays.deepToString(list));
        
        MMDevice iphone = new MMDevice("Iphone");
        MMDevice samsung = new MMDevice("Samsung", list);
        
         
        
        samsung.addFeature("FlashLight", "No");
        samsung.addFeature("1", "2");
        samsung.showFeatures();
        
    }
}