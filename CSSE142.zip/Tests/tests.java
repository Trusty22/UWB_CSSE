import java.util.*;
/**
 * Write a description of class tests here.
 * A basic 4 func calc that only does an action to 2 values at a time
 * @author Mandeep Masoun
 * @version (a version number or a date)
 */
public class tests
{
    public static Scanner s = new Scanner(System.in);
    public static int v1;
    public static int v2;
    public static void main(String args[]){
        System.out.println("Choose an operation");

        Cat[][] catzz = new Cat[2][3];
catzz[0] = new Cat[5];
        int k = 0, m = 5, n = 10, z = -3;
m--;
++n;
k = n * m;
k += m;
z = n;

System.out.println(z);
    }
    public static void add(){
        System.out.print("Enter an int value: ");
        v1 = s.nextInt();
        System.out.print("Enter another int value: ");
        v2 = s.nextInt();    
        System.out.println("Your added values are: " + (v1+v2) + "\n");
    }
    public static void sub(){
        System.out.print("Enter an int value: ");
        v1 = s.nextInt();
        System.out.print("Enter another int value: ");
        v2 = s.nextInt();    
        System.out.println("Your added values are: " + (v1-v2) + "\n");
    }
    public static void multi(){
        System.out.print("Enter an int value: ");
        v1 = s.nextInt();
        System.out.print("Enter another int value: ");
        v2 = s.nextInt();    
        System.out.println("Your added values are: " + (v1*v2) + "\n");
    }
       public static void dev(){
        System.out.print("Enter an int value: ");
        v1 = s.nextInt();
        System.out.print("Enter another int value: ");
        v2 = s.nextInt();    
        System.out.println("Your added values are: " + (v1/v2) + "\n");
    }
}
