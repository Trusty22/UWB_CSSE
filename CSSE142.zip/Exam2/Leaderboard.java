
/**
 * Write a description of class Instructor here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Leaderboard
{
    // instance variables - replace the example below with your own
    private String _name;
    private int _topScore;
    private Competitor[] _winner;

    /**
     * Constructor for objects of class Student
     */
    public Leaderboard(String name, Competitor person)
    {
        this._winner = new Competitor[5];

        if(name.length() < 2){
            this._name = "Alex";
        }else{
            this._name = name;
        }
        // for(int i = 0; i < _scores.length-1; i++){
        //   this._scores[i]=-1;
        // }

    }
    public void addComp(Competitor person){
        Competitor[] temp = new Competitor[this._winner.length+1];
        Competitor holding;
        for(int i = 0; i < this._winner.length; i++){ 
            if(person == this._winner[i]){
                this._topScore = person.getTopScore();
            }
        }
        for(int i = 0; i < this._winner.length; i++){ 
            holding = _winner[i];
            if(person.getTopScore() > this._winner[i].getTopScore()){
                System.out.println(person.getName()+"has a greater score than "
                    +this._winner[i].getName());
                  
                temp[i] = person;
            }
            for(int j = i+1; j< temp.length-1; j++){
                temp[j] = holding;
            }
        }
        this._winner = temp;
        this._topScore = temp[0].getTopScore();
    }
    
    public void dispWin(){
        for(int i = 0; i < this._winner.length; i++){ 
            System.out.println("#"+i+ ""+_winner[i].getName()+"With Score of "+_winner[i].getTopScore());
        }
    }
    private void setName(String name){
        this._name = name;
    }

    public String getName(){
        return this._name;
    }

    private void setTopScore(int score){
        if(score < 0 || score > 100){
            this._topScore = 0;
        }else{
            this._topScore = score;
        }        
        this._topScore = score;
    }

    public int getTopScore(){
        return this._topScore;
    }
}
