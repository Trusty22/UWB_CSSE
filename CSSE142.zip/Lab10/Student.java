
/**
 * Write a description of class Student here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Student
{
    // instance variables - replace the example below with your own
    private String first;
    private String last;
    
    /**
     * Constructor for objects of class Student
     */
    public Student()
    {
        // initialise instance variables
        this.first = "Thomas";
        this.last = "Shelby";
    }

    public void setFirst(String first){
        this.first = first;
    }
    
    public void setLast(String last){
        this.last = last;
    }
    
    public String getFirst(){
        return this.first;
    }
    
    public String getLast(){
        return this.last;
    }
    
    public String fullName(){
        return first + " "+last;
    }
}
