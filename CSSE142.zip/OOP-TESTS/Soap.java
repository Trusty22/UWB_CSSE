
/**
 * Write a description of class Soap here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Soap
{
    // instance variables - replace the example below with your own
    private int _size;
    private String _brand;
    public boolean _isLiquid;      
    private int _x;
    

    
    /**
     * Constructor for objects of class Soap
     */
    public Soap(int size, String brand, boolean isLiquid)
    {
        // initialise instance variables
        this._size = size;
        this._brand = brand;
        this._isLiquid = isLiquid;
     
    }

    
    public void applySoap(){
        //steps to apply
    }
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return _x + y;
    }
}
