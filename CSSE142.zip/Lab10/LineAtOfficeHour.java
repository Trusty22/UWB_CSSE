
/**
 * Write a description of class LineAtOfficeHour here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LineAtOfficeHour
{
    // instance variables - replace the example below with your own
    private Student[] line;
    private int n;
    private int back;

    /**
     * Constructor for objects of class LineAtOfficeHour
     */
    public LineAtOfficeHour()
    {
        // initialise instance variables
        this.line = new Student[5];
        
    }
    public LineAtOfficeHour(Student[] line)
    {
        // initialise instance variables
        this.line = new Student[5];
        
        for(int i = 0; i < this.line.length; i++){
            this.line[i] = line[i];
        }
        
    }
    
    public boolean isEmpty(){
        int count=0;
        for(int i = 0; i < this.line.length; i++){
            if(this.line[i] == null){
                count++;
            }
        }
        if(count == this.line.length-1){
            return true;    
        }
        return false;
    }
    public boolean isFull(){
        int count=0;
        for(int i = 0; i < this.line.length; i++){
            if(this.line[i] != null){
                count++;
            }
        }
        if(count == this.line.length){
            return true;    
        }
        return false;
    }
    public int size(){
        int count=0;
        for(int i = 0; i < this.line.length; i++){
            if(this.line[i] != null){
                count++;
            }
        }
        return count;
    }
    public void enterLine(Student student){
        for(int i = 0; i < this.line.length; i++){
            if(this.line[i] == null){
                this.line[i] = student;
                return;
            }
        }
        System.out.println("Error: line is full!");
    }
    public Student seeTeacher(){
        Student temp = this.line[0];
        this.line[0] = null;
        
        int count = 0;
        Student[] tempA = new Student[this.line.length];
        for(int i = 0; i < this.line.length; i++){
            if(this.line[i] != null){
                tempA[count] =  this.line[i];
                count++;
            }
        }
        this.line = tempA;
        return temp;
    }
    public void whosInLine(){
        for(int i = 0; i < this.line.length-1; i++){
            if(this.line[i] != null){
                System.out.print(this.line[i].fullName()+", ");
            }else{
                System.out.print("Empty, ");
            }
        }
        if(this.line[this.line.length-1] != null){
                System.out.println(this.line[this.line.length-1].fullName());
        }else{
                System.out.println("Empty");
        }
    }
}
