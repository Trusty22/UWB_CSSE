
/**
 * Write a description of class Pizza here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Pizza
{
    // instance variables - replace the example below with your own
    private String size;
    private int numOfTopMeat;
    private int numOfTopVeg;
    private boolean isVegan;
    
    /**
     * Constructor for objects of class Pizza
     */
    public Pizza()
    {
        this.size = "medium";
        this.numOfTopMeat = 0;
        this.numOfTopVeg = 0;
        isVegan = false;
    }
    
    public String getSize(){
        return this.size;
    }
    public int getMeat(){
        return this.numOfTopMeat;
    }
    public int getVeg(){
        return this.numOfTopVeg;
    }
    public boolean isVegan(){
        return this.isVegan;
    }
    
     public void setSize(String size){
        this.size = size ;
    }
    public void setNumOfTopMeat(int numOfTopMeat){
        this.numOfTopMeat= numOfTopMeat;
    }
    public void setNumOfTopVeg(int numOfTopVeg){
        this.numOfTopVeg = numOfTopVeg;
    }
    public void setVegan(boolean isVegan){
        this.isVegan = isVegan;
    }
    
    public Pizza(String size, int meat, int veg,boolean vegan)
    {
        if(vegan == true){
            meat = 0;
        }
        if(size.equalsIgnoreCase("small") 
        || size.equalsIgnoreCase("medium") || size.equalsIgnoreCase("large")){
            this.size = size;
        }else{
            System.out.println("This is not a size avalible: setting to default");
            size = "medium";
        }
        this.numOfTopMeat = meat;
        this.numOfTopVeg = veg;
        this.size = size;
        
    }
    
    public double calcCost(){
        double cost = 0.0;
        if(size.equalsIgnoreCase("small")){
            cost += 10;
        }else if(size.equalsIgnoreCase("medium")){
            cost += 12;
        }else if(size.equalsIgnoreCase("large")){
            cost += 14;
        }
        if(this.isVegan){
            cost+= 2;
        }else{
            cost += 2* this.numOfTopMeat + this.numOfTopVeg;
        }
        
        return cost;
    }
    
    public String getDescription(){
        String isVegan = "is not Vegan";
        if(this.isVegan){
            isVegan = "is Vegan";
            
        }
        return "This pizza is "+this.size + ", "+ isVegan + ", has " 
        + numOfTopMeat + " number of meat topings and " + numOfTopVeg
        + " number of veg topings and costs $" + calcCost()+ "0";
    }

    
}
