
/**
 * Write a description of class MMDriver here.
 *
 * Mandeep Masoun Driver class
 * 
 */
public class MMDriver
{
    
    public static void main(String args[]){
        positive();
        negitive();
        boundary();
        
    }
    
    public static void positive(){
        System.out.println("Positve Tests");
        MMStudent studentPos = new MMStudent("Mandeep", 5);
        
        studentPos.reportNewAssignmentScore(65);
        studentPos.viewAssignmentScores();
        studentPos.updateAssignmentScore(0,97);
    }
    public static void negitive(){
        System.out.println("\nNegitive Tests");
        MMStudent studentNeg = new MMStudent("a", -10);
        
        studentNeg.viewAssignmentScores();
        studentNeg.updateAssignmentScore(0,97);
        studentNeg.reportNewAssignmentScore(-65);
        
    }
    public static void boundary(){
         System.out.println("\nBoundary Tests");
         MMStudent studentBou = new MMStudent("Mandeep", 5);
         
         studentBou.reportNewAssignmentScore(0);
         studentBou.reportNewAssignmentScore(100);
    }
}
