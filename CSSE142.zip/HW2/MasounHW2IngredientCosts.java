import java.util.Scanner;
/**
 * Write a description of class MasounHW2IngredientCosts here.
 * 
 * By Mandeep Masoun
 * Prof Hansel Ong
 * Apr 13 2022
 * 
 * Hw 2 is about understanding the inflation in america,
 * so we have set forth to write a program that helps us do that.
 * 
 * This program is console based and it asks user about what types
 * of ingredients they want. Than asks the user if they want more (y/n)
 * then asks total cost of all combined ingredientsl. Then asks for inflation 
 * between 0-4.9%. Then asks for the amount of years(0-10) to calculate 
 * inflations effect on ingredient cost. There are many different test cases and
 * limitations that each differnt promopt has.
 * 
 * This assignment is made for us to learn about 
 * loops such as do while, while, and for,if statements,
 * boolean expressions, variable uses, Scanner uses,
 * methods and all their quirks(via arguments/parameters,return),
 * and how to properly use scope and other techniques.
 */
public class MasounHW2IngredientCosts
{
    public static void main(String args[]){
        Scanner userInput = new Scanner(System.in);
        boolean isMoreIngredients = true;
        boolean isValid = false;
        boolean isNotValidInf =true;
        boolean isNotPos = true;
        String food; 
        String ingredientsList = ""; 
        double cost;
        double inflation = 1;
        int years;
        
        do{   
            System.out.print("Please tell me an ingredient: ");
            food = userInput.nextLine();
            
            // checks if food is bigger than 2 letters and will keep asking until it is
            String newFood = confirmation(food);
            
            ingredientsList += newFood + "";
            //checks for y/n/invalid responses and loops, moves on, asks for a valid response
            do{
                System.out.print("Any other Ingredients to add? ");
                food = userInput.nextLine();
                
                if(food.toLowerCase().startsWith("y")){
                    isMoreIngredients = true;
                    ingredientsList += " + ";
                    isValid = true;
                }else if(food.toLowerCase().startsWith("n")){
                    isValid = true;
                    isMoreIngredients = false;                
                }else{
                    isMoreIngredients = true;           
                    isValid = false;
                    System.out.println("Invalid Response");
                }    
            }while(!isValid);
        }while(isMoreIngredients);
        
        //checks for valid positive number for cost
        do{
            System.out.print("What is the total cost of the ingredients? $");
            cost = userInput.nextDouble();
            if(cost <= 0){
                System.out.println("Invalid: Choose a positive number");
                isNotPos = true;
            }else{
                isNotPos = false;
            }
        }while(isNotPos);
        
        // checks for valid inflation cost from 0 to 4.9
        while(isNotValidInf){    
            System.out.print("What is the inflation rate? (Between 0 and 4.9% inclusive) ");
            inflation = userInput.nextDouble();
            if(inflation >= 0 && inflation <= 4.9){
                isNotValidInf = false;
            }else {
               System.out.println("Invalid inflation rate");
               isNotValidInf = true;
            }
        }
             
        //checks for valid years from 1-10
        System.out.print("Enter number of years to calculate inflation effect on "
        +"ingredient cost: ");     
        years = userInput.nextInt();
        while(years >= 10 && years <= 1){
            System.out.print("Input Invalid: must be between 1 and 10 years (inclusive)");
            System.out.print("Enter number of years to" +
            " calculate inflation effect on ingredient cost: ");  
            years = userInput.nextInt();

        }
        
        // increases inflation by calling a method increases that increases it 
        for(int i = 0; i < years; i++){
            System.out.printf("Year " + (2021 + i + 1) 
            + ": Cost of (" + ingredientsList + ") " + "is $%.2f\n", cost);
            
            cost = increaseInflation((inflation/100),cost);
            
        }
    }
    
    // increases inflation
    public static double increaseInflation(double inf, double cost){
        Scanner sc = new Scanner(System.in);
        double newCost = (cost + (cost * inf));
        return newCost;
    }
    //confirmation of length because I wanted to experiment with methods
    public static String confirmation(String check){
        Scanner sc = new Scanner(System.in); 
        while(check.length() < 2 || check.equals("")){
                System.out.println("Not Valid Ingredient"); 
                System.out.println("Please tell me a valid ingredient:");
                check = sc.nextLine();   
        }
        return check;
    }
}