
/**
 * Write a description of class o here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Person
{
    
    private String _name;
    private ClothingItem[] _clothes;

    /**
     * Constructor for objects of class o
     */
    public Person(String name)
    {
        this._clothes = new ClothingItem[5];
        if(name.length()<2){
            System.out.println("To small: Tom as default");
            name = "Tom";
        }
        this._name = name;
        ClothingItem shirt = new ClothingItem("shirt", "red");
        this._clothes[0] = shirt;
    }
    
    public String getName(){
        return this._name;
    }
    
    public void wearClothes(ClothingItem clothe){
        for(int i = 0; i< this._clothes.length; i++){
            if(this._clothes[i].equals(clothe) && this._clothes[i] != null){
                System.out.println("Can't add. You already have added this clothe");
                return;
            }
        }
        
        if(this._clothes[0] == null){
                this._clothes[0] = clothe;
                return;
        }else{
            ClothingItem temp = this._clothes[this._clothes.length-1];    
            for(int i = this._clothes.length - 2; i >= 0; i--){ 
                this._clothes[i +1] = this._clothes[i];
            }
            this._clothes[0] = temp;
            this._clothes[0]= clothe;      
        }
        
        ClothingItem[] newClothes = new ClothingItem[this._clothes.length+1];
        for(int i =0; i< this._clothes.length;i++){
            newClothes[i] = this._clothes[i];
        }
        newClothes[newClothes.length-1] = clothe;
        this._clothes = newClothes;
    }
    public void removeClothe(ClothingItem clothe){
        
        if(this._clothes[1] == null){
            System.out.print("You need clothes! You can't take that off!");
            return;
        }
        this._clothes[0] = null;
        
        ClothingItem[] temp = new ClothingItem[this._clothes.length]; 
        int count = 0;
        for(int i = 0; i< this._clothes.length;  i++){ 
            if(this._clothes[i]!= null){
               temp[count] = clothe;
               count++;   
            }
        }
    }
    public boolean equals(Person clothes){
        for(int i = 0; i< this._clothes.length;  i++){ 
            if(!(this._clothes[i].getType().equals(clothes._clothes[i].getType()))
            || !(this._clothes.length == clothes._clothes.length) ){
                return false;
            }
        }
        return true;
    }    
    
    public String toString(){
        return "This persons name is "+ this._name+ " they are wearing"
        + this._clothes.length+ " clothe(s)";
    }
    
}