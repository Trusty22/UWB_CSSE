import java.util.*;
import java.io.*;

/**
 * Write a description of class Advice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Advice
{
    public static void main(String args[]){
        PrintWriter outputAdv = null;
        PrintWriter outputLog = null;
        String stored;

        Scanner sc = new Scanner(System.in);
        while(true){
            try { 
                printAdv();

                System.out.println("Please give me some advice");

                FileWriter adv = new FileWriter("advice.txt",false);
                outputAdv = new PrintWriter(adv);

                FileWriter advLog = new FileWriter("adviceLog.txt",true);
                outputLog = new PrintWriter(advLog);

                stored = sc.nextLine();

                outputAdv.println(stored);
                outputLog.println(stored);

                if(stored.equals("")){
                    System.exit(0);    
                }
            }catch(IOException e) {
                System.out.println("File not found.");
                System.exit(0);    
            }

            outputAdv.close();
            outputLog.close();
        }
    }

    public static void printAdv(){
        System.out.println("Here's some advice for new programers!");
        try { 
            Scanner input = null;
            String adv ="";
            int rand = (int)(Math.random()*6)+1 ;
            input = new Scanner(new FileInputStream("AdviceIn.txt")); 
            for(int i=0; i< rand; i++){
                adv = input.nextLine();
            }

            System.out.println(adv);
        }catch(IOException e) {
            System.out.println("File not found.");
            System.exit(0);    
        }
    }
}