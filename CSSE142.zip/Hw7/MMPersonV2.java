
/**
 * Write a description of class MMPerson here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MMPersonV2
{
    private String _name;
    private MMPersonV2[] _friends;
    
    /**
     * Constructor for objects of class MMPerson
     */
    public MMPersonV2(String name)
    {
        // initialise instance variables
        if(name.length() < 2){
            this._name = "Tom";
        }else{
            this._name = name;
        }
        System.out.println("\n:"+this._name+" has been created:\n");
        _friends = new MMPersonV2[5];
    }
    
    public boolean equals(MMPersonV2 friend){
        if(this._friends == friend._friends){
            return true;
        }
        return false;
    }
    
    public String toString(){
        String s = "This person's name is " +this._name+ ". They have ";
        int count=0;
        for(int i = 0; i < this._friends.length; i++){
            if(this._friends[i] != null){
              count++;
            }
        }
        s += count + " friends.";
        return s;
    }
    
    public void addFriend(MMPersonV2 friend){
        //checks if arrays are ==
        if(this._friends.equals(friend._friends)){
            System.out.println("Cant add friend to your self! ");
            return;
        }
        for(int i = 0; i < this._friends.length; i++){
            if(this._friends[i] != null){
               if(this._friends[i].equals(friend)){
                   System.out.println("This friend has already been added! ");
                   return; 
                }
            } 
        }
        for(int i = 0; i < this._friends.length; i++){
            if(this._friends[i] != null){
                if(this._friends[i]._name.equals(friend._name)){
                   System.out.println("A friend with the name "+friend._name
                   +" has already been added to this list; Can't Add!");
                   return; 
                }
            }
        }
        
        for(int i = 0; i < this._friends.length; i++){
            if(this._friends[i] == null){
              this._friends[i] = friend;  
              System.out.println(friend._name+" has been added to "+this._name+"'s List!");
              return;
            }
        }
        System.out.println("Can't add to array, Array full");
    }
    
    public void addFriend(String name){
        MMPersonV2 person = new MMPersonV2(name);
        addFriend(person);
    }
    
    public void removeFriend(MMPersonV2 friend){
        for(int i = 0; i < this._friends.length; i++){
            if(this._friends[i] != null){
                if(this._friends[i].equals(friend)){
                    System.out.println(friend._name +" has been removed from "+ this._name +"'s list at index "+i);  
                    this._friends[i] = null;  
                    return;
                }
            }
        }
        System.out.println("Invalid: This friend isn't in the array no friends to remove!");
    }
    
    public void removeFriend(String name){
        if(name.length()< 2){
            System.out.println("Invalid Name: setting to default \"Tom\"");
            name = "Tom";
        }
        for(int i = 0; i < this._friends.length; i++){
            if(this._friends[i] != null){
                if(this._friends[i]._name.equals(name)){
                    System.out.println(name +" has been removed from index "+i);  
                    this._friends[i] = null;  
                    return;
                }
            }
        }
    }
    
    public void listFriends(){
        System.out.println("\nThis is "+ this._name +" friends List! ");
        for(int i = 0; i < this._friends.length; i++){
            if(this._friends[i] != null){
                System.out.println(this._friends[i].toString());
                
            }else{
                System.out.println("Index "+i+" is empty");
            }
        }
        System.out.println();
    }
    
    private void setName(String name){
        this._name = name;
    }
}