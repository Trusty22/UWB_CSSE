import java.util.*;
/**
 * Write a description of class CharsIndex here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CharsIndex{
    /**
     * Constructor for objects of class CharsIndex
     */
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        char toChar;
        int[] aToZPos = new int[26];
        char[] alphabet = new char[26];
        String line = sc.nextLine();
        for(int i = 97; i <123; i++){
            toChar = (char)i;
            aToZPos[i-97]=findWord(toChar,line);
            alphabet[i-97] = toChar;
        }
        
        printNum(aToZPos, alphabet, 0, 0);
        printEqual();
        printLet(aToZPos, alphabet, 0, 0);
        printNum(aToZPos, alphabet, 10, 10);
        printEqual();
        printLet(aToZPos, alphabet, 10, 10);
        printNum(aToZPos, alphabet, 20, 16);
        printEqual();
        printLet(aToZPos, alphabet, 20, 16);
    }

    public static void printNum(int[] aToZPos, char[] alphabet, int inc, int endInc){
        for(int i = 0+inc; i <= 9+endInc; i++){
            if(aToZPos[i]!=-1){
                if(i%10== 0){
                    System.out.print("\n");
                }
                System.out.print(alphabet[i]+ "  ");// +"  "+aToZPos[i]+" ");
            }
        }
        
    }
    
    public static void printLet(int[] aToZPos, char[] alphabet, int inc, int endInc){
        for(int i = 0+inc; i <= 9+endInc; i++){
            if(aToZPos[i]!=-1){
                if(i%10== 0){
                    System.out.print("\n");
                }
                System.out.print(aToZPos[i]+" ");
                if(aToZPos[i]>0 && aToZPos[i] <10){
                    System.out.print(" ");
                }
            }
        } 
        System.out.println();
    }
    public static void printEqual(){
        System.out.print("\n");
        for(int i =0; i<29; i++){
            System.out.print("=");
        }
    }
    public static int findWord(char letter, String input){
        Scanner sc = new Scanner(input);
        int i = input.indexOf(letter);

        return i;
    }
}