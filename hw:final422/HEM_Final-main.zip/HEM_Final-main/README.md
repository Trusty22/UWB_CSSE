# Team HEM Project
## ARM 2 Assembler for C functions

Group Members: Erik, Mandeep, Harman

Start up is located in HemFinal > RTE > Device/TM4C129XNCAZ > stratup.s
Other files are in the RTE
