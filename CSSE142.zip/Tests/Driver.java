import java.util.*;
/**
 * Write a description of class Driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Driver
{
    // instance variables - replace the example below with your own
    private int x;

   
    
     public static void main(String args[]){
        

        Cat[][] catzz = new Cat[2][3];
        catzz[0] = new Cat[5];
        for(int i =0; i< catzz.length; i++){
            for(int j = 0; j< catzz[i].length; j++){
             System.out.print(catzz[i][j]+ " ");
            }    
             System.out.println();
        }
        //System.out.println(Arrays.deepToString(catzz) );
        
}
}
