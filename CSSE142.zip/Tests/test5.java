import java.util.Scanner;
/**
 * Write a description of class test5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class test5
{
   public static void main(String args[]){
       /*Scanner s = new Scanner(System.in);
       System.out.println("print string");

       String sc = s.nextLine();
       System.out.println(sc.length());
       System.out.println("(y/n)");
       sc = s.nextLine();
       String newV;
       newV= sc.toLowerCase().startsWith("y") ? "ok" : sc.toLowerCase().startsWith("n") ? "ok" : "huh";;
       System.out.println(newV);
           
       
*/


int sum = 0;
for(int i = 0; i < 10; i++)
{
  for(int j = 0; j < 10; i++)
  {
    sum++;
  }
}

System.out.print(sum);
   }
}
