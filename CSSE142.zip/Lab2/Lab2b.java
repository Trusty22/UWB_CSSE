import java.util.*;
/*
 * Lab2b.java
 *
 * Authors: Samantha Smith, you
 */

// TODO: Do you need any imports?

public class Lab2b {
    public static void main(String[] args){
      /*  double maxNumber1 = Math.max(22.3, 34.5);
        double minNumber1 = Math.min(3.6/7.2, 3.8/6.9);
        double maxNumber2 = Math.max(2/3, 0.1);
        double minNumber2 = Math.min(13.5555, 13.5556);*/
        String numbers;
        String name;
        String num1, num2, num3;
        // TODO: Declare a Scanner
        Scanner sc = new Scanner(System.in);

        // TODO: Request and parse user input
        System.out.println("Please enter you name followed by three numbers (space separated):");
        String s = sc.nextLine();
        //mandeep 1 2 3 
        name = s.substring(0, s.indexOf(" ")); 
        //mandeep

        System.out.println("Hi there, "+ name
        +"! Here are the numbers you entered in descending order:");

        numbers = s.substring(s.indexOf(" ")+1); 
        //1 2 3 
        num1 = numbers.substring(0, numbers.indexOf(" "));
        //1
        numbers =  numbers.substring(numbers.indexOf(" ")+1); 
        //2 3
        num2 = numbers.substring(0, numbers.indexOf(" "));
        // 2
        numbers =  numbers.substring(numbers.indexOf(" ")+1); 
        num3 = numbers.substring(0);
        // TODO: Sort values and display

        System.out.println(sortDescending(num1, num2, num3));

        // TODO: Thank user
        System.out.println("Thank you for using the three-number-sorting system! Good-bye.");
        // mandeep 1 2 3 --> 3.0 2.0 1.0
        // john 89 12 9 --> 9.0 12.0 89.0
        // bob 8 -3 2--> -3.0 2.0 8.0
        // mack 9 8 2 --> 9.0 8.0 2.0
        // billy 6 7 8 --> 8.0 7.0 6.0
    }
    public static String sortDescending(String n1, String n2, String n3){
        double newNum1, newNum2, newNum3;
        double fNum1, fNum2, fNum3;
        double t1, min, biggest;

        newNum1 = Double.parseDouble(n1);
        newNum2 = Double.parseDouble(n2);
        newNum3 = Double.parseDouble(n3);
        
        double big = Math.max(newNum1, Math.max(newNum2, newNum3));
        double small = Math.min(newNum1, Math.min(newNum2, newNum3));
        double mid = (newNum1 + newNum2 + newNum3) - ( big + small );
        
        return big + " " + mid + " " + small;
    }
    // Declare a sortDescending method that will take three doubles (optional)
}
