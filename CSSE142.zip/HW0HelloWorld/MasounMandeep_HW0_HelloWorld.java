import java.util.Scanner;
import java.io.*;
/**
 * This is a a simple program to introduce myself a bit more, 
 * and demonstrate simple math expressions by writing code. 
 * @auther Mandeep Masoun
 * @version March/29/2022 
 * 
 */
public class MasounMandeep_HW0_HelloWorld
{
    // I would like to see nueral implants come to reality 
    // where we would be able to control our phones through our brains
    // and comunicate with others by just thinking about it
    public static void main(String[] args){
        // creates variables and/or defines them
        String firstAndLastName = "Mandeep Masoun";
        double moneyAfterGrad = 120000.89;
        double payIncrease;
        String newForm;
        //prints my name and text
        System.out.println("My name is: "+ firstAndLastName);
        // stores the amount of money I make in my first year
        // the amount is formated with decimals 
        //and commas by the format() method
        newForm = format(moneyAfterGrad);
        System.out.println("I wish to make: $" + newForm
                                + " after my first year of graduation");
        // increase by 3% and do the same as previous line
        payIncrease = moneyAfterGrad * 1.03;
        System.out.println("I wish to make: $" + format(payIncrease)
                                + " after my 2nd year of graduation");
        // increase by 3% and do the same as previous line                                
        payIncrease = payIncrease * 1.03;
        System.out.println("I wish to make: $" + format(payIncrease) 
                                + " after my 3rd year of graduation");

    }
    //This method formats the given int by adding
    //a comma to each thousands place 
    //then it returns it as a string
    public static String format(double n){
        // creates variables and/or defines them
        int flag = 0;
        String str1 = n + "";
        String temp = "";
        String end;
        
        //sets the ending for the decimals 
        end = str1.substring(str1.indexOf("."),str1.indexOf(".") + 3);
        //sets only the numbers < 1
        str1 = str1.substring(0, str1.indexOf("."));

        //Takes the given numberand parses through it 
        // by looping backwords and after every 3rd spot add comma      
        for(int i = str1.length() - 1 ; 0 <= i; i-- ){ 
            //add a flag to detect for every 3rd spot
            flag++;
            temp = str1.charAt(i) + temp;
            
            //Check if this is the third spot by 
            //using the mod operator and add comma to the front of the number 
            if(flag % 3 == 0){
                temp = "," + temp;
                flag = 0;
            } 
        } 
        
        // checks for wether comma is at the front
        // if it is, in case of even numbers of 3 length, 
        // return everything after the first comma 
        // ex. 123, 100000
        if(temp.startsWith(",")){
                // returns everything after comma 
                return temp.substring(1,temp.length()) + end;
        }
        return temp + end;
    }
}
