
/**
 * Write a description of class Driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Driver
{
    public static void main(String args[]){
        positive();
        negitive();
        boundery();
    }

    public static void positive(){
        Competitor c1 = new Competitor("Jeff",70);
        Competitor c2 = new Competitor("toomas", 79);
        
        Leaderboard l1 = new Leaderboard("AppleMan",c1);
        l1.addComp(c2);
        l1.dispWin();
    }

    public static void negitive(){
        Competitor c1 = new Competitor("a",-11);
        
        Leaderboard l1 = new Leaderboard("o",c1);
        c1.newScore(100001);
        
    }

    public static void boundery(){
        Competitor c = new Competitor("l",50);
        
        
        Competitor c1 = new Competitor("Mandeep",99);
        c1.newScore(80);
        
        Competitor c2 = new Competitor("jaideep",1);
        c1.newScore(80);
    }

}
