
/**
 * Write a description of class Item here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Item
{
    // instance variables - replace the example below with your own
    private String _name;
    private double _cost;

    /**
     * Constructor for objects of class Item
     */
    public Item(String name, double cost)
    {
        // initialise instance variables
        if(name.length() < 2){
            System.out.println("Name can't be less than 2 length, setting name to Tom");
            name = "Tom";
        }
        if(cost < 0){
            System.out.println("Cost can't be less than 0");
            cost = 0;
        }
        
        this._name = name;
        this._cost = cost;
    }
    
    public String getName(){
        return this._name;
    }
    
    public void setName(String name){
        if(name.length() < 2){
            name = "Tom";
        }
        this._name = name;
    }
    
    public double getCost(){
        return this._cost;
    }
    
    public void setCost(double cost){
        if(cost < 0){
            System.out.println("Cost can't be less than 0");
            cost = 0;
        }
        this._cost = cost;
    }
    
    public boolean equals(Item item){
        if(this._cost == item._cost && this._name.equals(item._name)){
            return true;
        }
        return false;
    }
    
    public String toString(){
        
        return "This is a(n) "+this._name+" it costs $"+this._cost;
    }

}
