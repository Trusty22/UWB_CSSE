import java.util.Scanner;
import java.util.*;

/**
 * Description of this class here
 */


public class Lab5 {

    public static void main(String[] args)  {
        
    Scanner sc = new Scanner(System.in);
   
    while (true){
        menu();
        int choice =sc.nextInt();
        if(choice == 0){
            System.exit(0);
        }
        if(choice == 1){
            getRichQuick();     
        }
        if(choice ==2){
            System.out.println("what number do you want to calculate e^x for any real x");
             double x = sc.nextDouble();
             
             System.out.println(eTaylor(x));
        }
        if(choice ==3){
            palindromeCheck();
        }
        if(choice ==4){
            menu();
        }
    }
        // Test your methods by calling them here
                            // Should run your method
           // Will call your method with a parameter. Now display the return value from your method        
        
                               // test your method
    }
    public static void menu(){
        System.out.println("Welcome to Lab5!\n"+
    "Enter 1 to check how long it takes to get rich on a magic dollar coin.\n"+
    "Enter 2 to calculate e^x for any real x.\n"+
    "Enter 3 to enter palindrome words.\n"+
    "Enter 4 to re-print the menu.\n"+
    "Enter 0 to exit.");
    }
    // Part 1
     public static void getRichQuick() {
        // Declare your variables here and implement your logic
        int i;
        double money = 1.0;
        double half = 1.0;
        int days = 1;
       // boolean flag = true;
        System.out.println("Day 1: $" + money);
        //finds out that it takes 33 days to get higher than 1 million by doing maths
        for(i = 1; true; i++){
            half =  1.5*half;
            System.out.printf("Day "+ (i+1) 
            + ": $%.2f + ($1 + %.2f) = $%.2f\n",money,half,( money+half));
            money = money + (half);

            if(money > 1000000){
                System.out.printf("Day "+ (i+1) + ": $%.2f + ($1 + %.2f) >= $1000000\n",money,half);
                
                break;
            }
            
        }
        
    }
    
    // Part 2 
    public static double eTaylor( double x ) {
        double taylorNumber = 1.0;
        // Does math for e^x
        double factorial = 1;
        for(int i = 0; taylorNumber < 100000000;i++){
            
            taylorNumber += (taylorNumber + ( multi(taylorNumber,x)))/eTaylorHelper(taylorNumber,i);
            
        }
        
        
        return taylorNumber;
    }
    
    public static double multi(double x,double power){
        //multiplies power amount of times
        double num = 5.0;
        for(int i = 0; i < power; i++){
            x *=  x;
        }
        
        return x;
    }
    
    public static double eTaylorHelper(double x, int n){
        double power = 1;
        double factorial = 1;
        
        for(int i = 1; i <= n; i++){
            power = power * x;
            factorial = factorial * i;
        }
        
        return power / factorial;
    }
      
      
      
    // Part 3
    /**
     * This program reads words, identifies, counts and writes all the palindromes and the total
     * palindrome count.
     * 
     * // hint 1: Using keybord.next() will only return what comes before a space.
       // hint 2: Using keybord.nextLine() automatically reads the entire current line.
     */
    public static void palindromeCheck(){

       String someWord = ""; // Stores words read from user input
       int count = 0;        // keeps track of Palindrome words only (define algorithm to count # of palindrome words
       int total = 0;        // Counts the total number of lines read from the given text file
       boolean isPali = true;
       
       System.out.println(" Enter some words separated by white space");    // Ask for user input
      
       // declare your Scanner object here
       Scanner keyboard = new Scanner(System.in);

       // for each word user enters
       while (keyboard.hasNext()) {
           someWord = keyboard.next();          // store each word in a string variable and then do your operations
           total++;                             // increment number of words as you read each one
           int size = someWord.length();
           //System.out.println(size);
           // #1. Code your logic for how to determine if a word is Palindrome first, then complete # 2
           for(int i = 0; i<size;i++){
               if(someWord.charAt(i) != someWord.charAt(size - i - 1)){
                System.out.println(someWord + " is not palindrome!");
                isPali = false;
                break;
              }
           }
           if(isPali){
               System.out.println(someWord + " is a palindrome!");
            }
          
          System.out.println("  " + total + " " + someWord);   // test
        }
    }
}