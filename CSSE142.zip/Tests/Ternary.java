
/**
 * Write a description of class Test4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ternary
{
    public static void main(String args[]){
        //binary requires 2 
        //ternary requires 3 thingd
        //           // conditional, ? what if true, what if false
        // ternarry statment 
        String mes = (5<4) ? "5 is less then 4" : "4 is less than 5";
        System.out.println(mes);
        
    }
}
