import java.util.*;
/**
 * Mandeep Masoun
 * March 30
 */
public class ScannerTest
{
    public static void main(String[] args){
        System.out.println("Enter a valid number:");
        Scanner s = new Scanner(System.in);
        int sc = s.nextInt();        

        System.out.println(multibyfive(sc));
    }
    
    public static int multibyfive(int s){    
        return s*5;
    }
}
