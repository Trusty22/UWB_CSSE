
/**
 * Write a description of class Racing here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Racing
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Racing
     */
    public Racing()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public Car typeOfCar(Car car)
    {
        Car race = car;
        return race;
    }
}
