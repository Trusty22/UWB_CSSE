/**
 * Write a description of class MMPerson here.
 * Mandeep Masoun
 * May 15
 */
public class MMPerson
{
    // instance variables - replace the example below with your own
    private String _name;
    private MMPerson _friends[];

    /**
     * Constructor for objects of class MMPerson
     */
    public MMPerson(String name)
    {
        // initialise instance variables
        if(name.length()<2){
            System.out.println("Error: Name is too small setting defaulting to Tom");
            name = "Tom";
        }
        this._name = name;

        this._friends = new MMPerson[5];
        System.out.println("\n:Person "+this._name+" was created:\n");
    }
    public void addFriend(MMPerson friend){   
        if(this._friends ==friend._friends){
            System.out.println("The friend "+friend._name +" can't be to added to it self. "
                + "You can't be your own friend! ");
            return;
        }

        for(int i = 0; i< this._friends.length; i++ ){
            if(this._friends[i] == friend){
                System.out.println("Friend already in array! You can't re-add " 
                + this._friends[i]._name);
                return;
            }   
        }

        for(int i = 0;i< this._friends.length; i++ ){
            if(this._friends[i] == null){
                this._friends[i] = friend;
                System.out.println("Friend "+friend._name+" has been added to index "
                    +i+" to " +_name+ "'s array");
                return;
            }
        }

        System.out.println("\nError: Array is already full."+
            "\nSo, Expanding and adding friend! Auto-Magiclly expanding array!\n");
        expandArray(friend);
    }

    public void expandArray(MMPerson friend){
        MMPerson tempFriends[] = new MMPerson[this._friends.length+1];
        for(int i = 0;i< this._friends.length; i++ ){
            tempFriends[i] = this._friends[i];
        }
        this._friends = tempFriends;
        addFriend(friend);
    }

    public void removeFriend(MMPerson friend ){
        for(int i = 0;i< this._friends.length; i++){
            if(this._friends[i] == friend){
                this._friends[i] = null;
                System.out.println("Friend "+friend._name+" has been removed from array "+i);
                return;
            }
        }
        System.out.println("This friend does not exist or has been removed from the index ");

    }

    public void listFriends(){
        for(int i = 0;i< this._friends.length; i++ ){
            if(this._friends[i] == null){
                System.out.println("Index "+i+" is empty in "+_name +"'s array");
            }else{
                System.out.println("The friend "+
                    this._friends[i]._name +" occupies index "+i+" in "+_name +"'s array");
            }
        }
    }

    private void setName(String name){
        this._name = name;
    }

    public String getName(){
        return this._name;
    }
}