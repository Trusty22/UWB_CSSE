import java.util.*;
/**
 * Write a description of class Q1MasounMandeepExam1Part2 here.
 *
 * Name: Mandeep Masoun 
 * Student ID#: 2121617
 * Date: Apr 18
 * Prof: Hansel Ong
 * 
 */
public class Q3MasounMandeepExam1Part2
{
    
   public static void main(String[] args){
       
   }
   public static int guess(){
       Scanner sc = new Scanner(System.in);
      // int rand = (int)(Math.random()*10);
       
       Random rn = new Random();
       int rand = rn.nextInt(10) + 1;
       System.out.println(rand);
       int timesToguess = 4;
       int num;
       
       while(timesToguess >=0){
           System.out.println("Please guess a number from 0 to 10. You have "+(timesToguess+1)+" attempts");
           
           num = sc.nextInt(); 
           
           if(num == rand){
             System.out.println("You Got it!");
             
               return timesToguess;
           }else{
             System.out.println("Try again");
             timesToguess--;
    
           }
           
       }
    
       return 5;
   }
}
