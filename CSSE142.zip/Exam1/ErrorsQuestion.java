import java.util.*;
/**
 * Write a description of class Q1MasounMandeepExam1Part2 here.
 *
 * Name: Mandeep Masoun 
 * Student ID#: 2121617
 * Date: Apr 18
 * Prof: Hansel Ong
 * 
 */

public class ErrorsQuestion{
  public static void main(String[] args){
    //forgot new
    Scanner numbers = new Scanner(System.in);
    // forgot nextInt()
    // should ask user nummber of times to repeat
    System.out.println("How many number of times to repeat?");
    int x = numbers.nextInt();

    int batman;
    boolean endLoop;
    do{
      //forgot ""
      System.out.println("would you like to sing?");
      // no need for Sing(x) just Sing
      System.out.println(Sing());
    
      //batman not initialized
      batman=  5 ;
      //end loop has no variable type should be bool
      endLoop = false;
      //no while and needs to be ==
      // logic error needs
    }while(x == 0);
    
    // should be endloop not batman
    //print batman dont not return
    if (endLoop)
      //no return
      System.out.println(batman);
    }
  

  /*
   * Batman!
   */
  public static String batman(){
      // forgot quotes and semicolen
    return "Batman!";
  }

  /*
   * Sing
   */
  //forgot static
  //return as String
  public static String Sing(){
      //should return Na! not print
    return "Na!";
  }
  
} 
   

