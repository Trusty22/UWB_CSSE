
/**
 * Write a description of class TempTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TempTester
{
    // instance variables - replace the example below with your own
    public static void main(String[] args){
        // test no args constructor
        Tempature temp1 = new Tempature();   
        //test to string and getTempInF/C
        System.out.println(temp1.compare());
        System.out.println(temp1.toString()+" = " + temp1.getTempInF() +" F\n");
        
        
        // test args constructor
        Tempature temp2 = new Tempature(-40,'c');  
        //test compare
        System.out.println(temp2.compare());
        System.out.println(temp2.toString()+" = " + temp2.getTempInF() +" F\n");
        
        
        
        Tempature temp3 = new Tempature(100, 'c');   
        System.out.println(temp3.compare());
        System.out.println(temp3.toString()+" = " + temp3.getTempInF() +" F\n");
         
        //tests setting temp,scale,and temp and sclae sogether
        Tempature temp4 = new Tempature();   
        temp4.setTemp(420);
        temp4.setScale('f');
        System.out.println(temp4);
        
        temp4.setScaleAndTemp('c',22);
        System.out.println(temp4);
    }
}