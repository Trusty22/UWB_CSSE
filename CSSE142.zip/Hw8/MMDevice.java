import java.util.*;
/**
 * Write a description of class MMDevice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MMDevice
{
    private String _deviceName;
    private String[][] _featuresList;
    /**
     * Constructor for objects of class MMDevice
     */
    public MMDevice(String deviceName)
    {
        if(deviceName.length()< 2){
            System.out.println("Invalid Name seting to default");
            deviceName = "Iphone";
        }
        this._featuresList = new String[2][10]; 
        
        this._featuresList[0][0] = "Height";
        this._featuresList[1][0] = "6 INCH";
        
        this._featuresList[0][1] = "Weight";
        this._featuresList[1][1] = ".25 LB";
        
        this._featuresList[0][2] = "Color";
        this._featuresList[1][2] = "red";
        
        this._deviceName = deviceName;
        
        System.out.println(":A(n) "+this._deviceName+" has been created:");
    }

    public MMDevice(String deviceName, String[][] featuresList)
    {
        // initialise instance variables
        if(deviceName.length() < 2){
            System.out.println("Invalid Name seting to default");
            deviceName = "Iphone";
        }
        this._featuresList = featuresList;
        if(!this._featuresList[0][0].equals("Height")){
            System.out.println("Error: Device needs a height... Seting default");
            this._featuresList[0][0] = "Height";
            this._featuresList[1][0] = "6 INCH";
        }
        
        if(!this._featuresList[0][1].equals("Weight")){
            System.out.println("Error: Device needs a Weight... Seting default");
            this._featuresList[0][1] = "Weight";
            this._featuresList[1][1] = " .25 LB";
        }
        
        if(!this._featuresList[0][2].equals("Color")){
            System.out.println("Error: Device needs a Color... Seting default");
            this._featuresList[0][2] = "Color";
            this._featuresList[1][2] = "Red";
        }
      
        this._deviceName = deviceName;
        
        this._featuresList = featuresList;
        System.out.println(":A(n) "+this._deviceName+" has been created:");
    }

    public void showFeatures(){
        boolean flag = false;
        boolean isEmpty = true;

        for(int i = 0; i < this._featuresList.length; i++){
            for(int j = 0; j < this._featuresList[i].length; j++){
                if(this._featuresList[i][j]!= null){
                    flag = true;
                    isEmpty = false;
                    break; 
                }
            }
            if(flag){
                break;  
            }
        }
        if(isEmpty){
            System.out.println("There are no features in this Device! Can't print.");
            return ;
        }
        
        for(int i = 0; i < this._featuresList.length; i++){
            for(int j = 0; j < this._featuresList[i].length; j++){
                if(this._featuresList[i][j]== null){
                    this._featuresList[i][j] = " Empty ";
                }
            }
        }
        
        
       // printLine();
        System.out.println();
        for(int i = 0; i < this._featuresList.length-1; i++){
            for(int j = 0; j < this._featuresList[i].length; j++){
                System.out.println("|"+this._featuresList[i][j] + " | " 
                + this._featuresList[i+1][j] + "|");
                //printLine();   
            }
            
        }
    }

    public boolean equals(String[][] featuresList){
        if(this._featuresList == featuresList){
            return true;
        }
        return false;
    }

    public String toString(){
        return "\nThis devices is a(n) "+ this._deviceName;
    }

    public void setDeviceName(String deviceName){
        this._deviceName = deviceName;
    }

    public String getDeviceName(){
        return this._deviceName;
    }

    public void addFeature(String featureName, String value){
        if(featureName.length()< 2){
            System.out.println("Invalid feature name can't add");
            return;
        }
        
        if(value.length()< 2){
            System.out.println("Invalid value  can't add");
            return;
        }
        //System.out.println(Arrays.deepToString(this._featuresList));
        if(!isValidConfig()){
            return;
        }
        
        for(int i = 0; i < this._featuresList.length; i++){
            for(int j = 0; j < this._featuresList[i].length-1; j++){
                //System.out.println((this._featuresList[i][j] + " "+ featureName));
                if(this._featuresList[i][j]!= null && this._featuresList[i][j].equals(featureName)){
                    this._featuresList[i+1][j] = value + " <-- " + this._featuresList[i+1][j];
                    System.out.println(featureName + " updated!");
                    return;
                }
                if(this._featuresList[i][j] == null && this._featuresList[i][j+1] == null){
                    this._featuresList[i][j] = featureName;
                    this._featuresList[i+1][j] = value;
                    return;
                }
            }  
        }
        System.out.println("Error Array Full: can not add " + featureName);
    }

    public boolean isValidConfig(){
        // is valid:
        // if >4 and <6 than it can only be red and blue with weight >.15 and <.25
        // if >6 and <8 than it can only blue and black with weight of >=.25 and =<.5
        // if >8 and <10 than it can only black and grey with weight >.5 and <.65
        int height = Integer.parseInt(this._featuresList[1][0].substring(0, this._featuresList[1][0].indexOf(" ")));
        double weight = Double.parseDouble(this._featuresList[1][1].substring(0, this._featuresList[1][1].indexOf(" ")));
        String color = this._featuresList[1][2];
        //System.out.println(height+" " + weight+" " +color);
        if(!isValidHeight(height, weight, color)){
            return false;
        }
        return true;
    }

    public boolean isValidHeight(int height, double weight, String color){
        if(height>= 4 && height<= 6){
            return isValidWeight(weight, color, 0);
        }else if(height> 6 && height<= 8){
            return isValidWeight(weight, color, 1);
        }else if(height> 8 && height<= 10){
            return isValidWeight(weight, color, 2);
        }
        System.out.println("Invalid Height:"+
            " This Height is not avalible with this device config or is to Much/Little");
        return false;
    }

    public boolean isValidWeight(double weight,String color, int type){
        if(weight>= .15 && weight<= .25 && type == 0 ){
            return isValidColor(color, type);
        }else if(weight> .25 && weight<= .5 && type == 1){
            return isValidColor(color, type);
        }else if(weight> .5 && weight<= .65 && type == 2){
            return isValidColor(color, type);
        }
        System.out.println("Invalid Weight:"+
            " This weight is not avalible with this device config or is to Much/Little");
        return false;
    }

    public boolean isValidColor(String color, int type){
        String newColor = color.toLowerCase();
        //System.out.println(type);
        if((newColor.equals("red") || newColor.equals("blue")) && type==0){
            return true;
        } else if((newColor.equals("blue") || newColor.equals("black")) && type==1){
            return true;
        }else if((newColor.equals("black") || newColor.equals("grey")) && type==2){
            return true;
        }
        System.out.println("Invalid Color:"+
            " This is not a color or it's not avalible with this device or its configs ");
        return false;
    }

    public void printLine(){
        System.out.println();
        for(int i = 0; i < this._featuresList[0][0].length()+2; i++) {
            System.out.print("+-");
        }
        System.out.println("+");  
    }
}

