
/**
 * Write a description of class Driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Driver
{
    public static void main(String args[]){
        ClothingItem pants = new ClothingItem("pants", "red");
        ClothingItem jeans = new ClothingItem("jeans", "red");
        ClothingItem shorts = new ClothingItem("shorts", "red");
        
        Person alex = new Person("Alex");
        alex.wearClothes(pants);
        alex.wearClothes(jeans);
        alex.wearClothes(shorts);
        
        alex.wearClothes(pants);
        
        ClothingItem pants1 = new ClothingItem("pants", "blue");
        ClothingItem jeans2 = new ClothingItem("jeans", "blue");
        ClothingItem shorts3 = new ClothingItem("shorts", "blue");
        
        Person john = new Person("Alex");
        john.wearClothes(pants);
        john.wearClothes(jeans);
        john.wearClothes(shorts);
        
        alex.equals(john);
        
        
        
        ClothingItem shirt = new ClothingItem("tshirt", "red");
        ClothingItem glasses = new ClothingItem("glasses", "red");
        
        
        Person appleman = new Person("appleman");
        appleman.wearClothes(shirt);
        appleman.wearClothes(glasses);
        
        
        alex.equals(appleman);
        
       
        
       
        
        
        
    }
    
    public static void positive(){
        
    }
    
    public static void negitive(){
        
    }
   
}
