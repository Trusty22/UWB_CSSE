import java.util.*;
/**
 * Write a description of class Lab7a here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lab7a
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Lab7a
     */

    public static void main(String args){

    }

    public static String capitalizeFirstLetters(String input) {
        Scanner sc = new Scanner(input);
        String newS = "";
        String temp;
        String firstL;
        String end ="";
        while(sc.hasNext()){
            temp = sc.next();
            firstL = temp.substring(0,1).toUpperCase();
            if(temp.length() < 2){

            } else{
                end = temp.substring(1);
            }
            newS += firstL + end + " ";
        }
        newS = newS.substring(0,newS.length()-1);
       return(newS);
        //TODO: parse input for words and capitalize each one.
    }

    public static String nameInitials(String input) {
        Scanner sc = new Scanner(input);
        String newS = "";
        String temp;
        String firstL;

        while(sc.hasNext()){
            temp = sc.next();
            firstL = temp.substring(0,1).toUpperCase();
            newS += firstL + ".";
        }
        newS = newS.substring(0,newS.length());
        return(newS);
        //TODO: parse input for words and capitalize each one.
    }

    public static String lexLargest(String input) {
        String[] words = fillArr(input);
        
        Arrays.sort(words,String.CASE_INSENSITIVE_ORDER);   
        
        return words[words.length-1];
    }
    
    public static String largestBy(String input) {
        String[] words = fillArr(input);
        String largest = words[0];
        
        for(int i = 1; i <words.length; i++){
            if(largest.length()< words[i].length()){
                largest =  words[i];
            }
        }
        
        return largest;
    }

    public static String[] fillArr(String input){
        Scanner sc = new Scanner(input);
        int count = 0;
        String[] arr;
        
        while(sc.hasNext()){
            sc.next();
            count++;
        }
        
        arr = new String[count];
        sc = new Scanner(input);

        count = 0;
        while(sc.hasNext()){
            arr[count] = sc.next();
            count++;
        }
        return arr;
    }
    
    
}
