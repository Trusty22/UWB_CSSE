/*
 * Lab3b.java
 *
 * Parts 3 and 4
 *
 * Author: Samantha Smith, you
 */

public class Lab3b {
    public static void main(String[] args) {
        part3();
        // smallestOfThree tests
        System.out.println("\nTesting greaterOfTwo:");
        System.out.println(greaterOfTwo(-3, 6.2));
        System.out.println(greaterOfTwo(16, 7));
        System.out.println(greaterOfTwo(22, -1.2));


        // smallestOfThree tests
        System.out.println("\nTesting smallestOfThree:");
        System.out.println(smallestOfThree(3, 17, 8));
        System.out.println(smallestOfThree(8, 1, 7));
        System.out.println(smallestOfThree(2.5, 9.999999, -4));

    }
    /**
     * part3
     *
     * Sanity check for handwritten work
     */
    public static void part3() {
        boolean isFiveLess = 5 < 15;
        int n = 4;
        boolean isEven = ( n % 2 == 0 );
        boolean isOdd = ! ( isEven );
        boolean isTenLessOrEqual = ( 10 <= 100/10 );
        int a = 3;
        int b = 5;
        boolean isALess = a < b;
        
        // add print statements
        System.out.println(isFiveLess);
        System.out.println(isEven);
        System.out.println(isOdd);
        System.out.println(isTenLessOrEqual);
        System.out.println(isALess);
        

    }

    /**
     * greaterOfTwo part 4
     *
     * Return the gereater of the two values without using Math.max or Math.min
     *
     * @param    num1    double
     * @param    num2    double
     * @return    
     */
    public static double greaterOfTwo(double num1, double num2){
        if(num1 > num2){
            return num1;
        } else if(num1 < num2){
            return num2;
        }
        return num1;            
    }

    /**
     * smallestOfThree part 4
     *
     * Return the smallest of the three values without using Math.max or Math.min
     *
     * @param    num1    double
     * @param    num2    double
     * @param    num3    double
     * @return    
     */
    // figure out the declaration and the method!
    //2.5, 9.999999, -4)
        public static double smallestOfThree(double num1, double num2, double num3){
        if(num1 > num2){
            if(num2 > num3){
                return num3;
            }else if(num2 < num3){
                return num2;
            }
        } else if(num1 < num3){
            return num1;
        }
        return num3;
    }
}
