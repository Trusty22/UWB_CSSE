import java.util.Scanner;

/*
 * Lab2a.java
 *
 * Authors: Samantha Smith, mandeep
 */
// TODO: Import Scanner

public class Lab2a {
    public static void main(String[] args){
        // kelvins and temperaturePrinter tests
        System.out.println("\nTesting kelvins and temperaturePrinter:");
        double f1 = 32;
        temperaturePrinter(f1, kelvins(f1));
        // TODO: Add at least five tests
        f1 = 72;
        temperaturePrinter(f1, kelvins(f1));
        f1 = 60;
        temperaturePrinter(f1, kelvins(f1));
        f1 = 7;
        temperaturePrinter(f1, kelvins(f1));
        f1 = 52;
        temperaturePrinter(f1, kelvins(f1));
        f1 = 120;
        temperaturePrinter(f1, kelvins(f1));    

        // inSeconds tests
        System.out.println("\nTesting inSeconds:");
        inSeconds(1, 5, 1); // Expect: 3901
        // TODO: Add at least 5 tests
        
        inSeconds(2, 4, 12); // Expect: 7452
        inSeconds(3, 5, 5);  // Expect: 11105
        inSeconds(0, 1, 18); // Expect: 78
        inSeconds(8, 8, 22); // Expect: 29302
        inSeconds(6, 4, 51); // Expect: 21891
        
        // secondTime tests
        System.out.println("\nTesting secondTime:");
        secondTime(213);   //213 seconds == 0:3:33
        secondTime(5423);  //5423 seconds == 1:30:23
        secondTime(78922); // 78922 seconds == 21:55:22
        secondTime(2673);  //2673 seconds == 0:44:33
        secondTime(43);    // 43 seconds == 0:0:43
        // TODO: Declare a scanner
        Scanner sc = new Scanner(System.in);
        System.out.println("\nPlease input total seconds as an integer");
        
        
        int val = sc.nextInt();            
        secondTime(val);
        inSeconds( 0, 2, 0 );
        
        inSeconds( 0, 2, 0 );
        secondTime( 9001 );
        inSeconds( 24, 0, 0 );
        secondTime( 3600 );
        inSeconds( -1, 61, -60 );

    }

    /**
     * kelvins
     *
     * This method converts a value in F to the corresponding value in K.
     *
     * @param   f   double  The temperature in Farenheit
     * @return  The temeprature in Kelvins
     */
    public static double kelvins(double f) {
        // 50deg f == 283.15
        return ((f-32)*5/9+273.15);
    }

    /**
     * temperaturePrinter
     *
     * This method prints the message "<f> F corresponds to <k> K"
     *
     * @param   f   double  The temperature in Farenheit
     * @param   k   double  The temperature in Kelvins
     */
    public static void temperaturePrinter(double f, double k) {
       System.out.printf(f + " deg. F equals %.2f deg. K\n", k);
    }



    /**
     * secondTime
     *
     * This method converts from seconds to hour:minutes:seconds, and prints the
     * result to the console.
     *
     * @param   inputSeconds    int The total seconds to convert
     */
    // TODO: You figure out the declaration and the method!
    public static void secondTime(int seconds){
    
       int min = ((seconds/60));
       int newMin = min % 60;
       int sec = (seconds % 60);
       int hours = min/60;
       System.out.println(seconds + " seconds == " + hours + ":" +newMin+":"+sec);
    }
    /**
     * // mod min by the maximum amount of minutes 
     * inSeconds
     *
     * This method converts from hours:munites:seconds to seconds, and prints the
     * result to the console.
     *
     * @param   hours   int The hours to convert
     * @param   mins    int The minutes to convert
     * @param   secs    int The seconds to convert
     * @return The total number of seconds
     */
    public static void inSeconds(int hours,int min,int sec){
       int convertion = (hours * 60 * 60) + (min * 60) + sec;
       System.out.println(hours + ":" + min + ":" + sec + " == " + convertion + " seconds");
        
    }
    
}
