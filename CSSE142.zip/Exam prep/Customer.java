
/**
 * Write a description of class Customer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Customer
{
    // instance variables - replace the example below with your own
    private String _name;
    private Item[] _items;

    /**
     * Constructor for objects of class Customer
     */
    public Customer(String name)
    {
        if(name.length() < 2){
            System.out.println("Name can't be less than 2 length, setting name to Tom");
            name = "Tom";
        }
        this._items = new Item[5];
    }
    
    public void addItem(Item item){
        for(int i =0; i< this._items.length;i++){
            if(this._items[i] == null){
                this._items[i] = item;
                return;
            }
        }
        
        Item[] newItems = new Item[this._items.length+1];
        
        for(int i =0; i< this._items.length;i++){
            newItems[i] = this._items[i];
        }
        //System.out.println(newItems.length);
        newItems[newItems.length-1] = item;
        
        this._items = newItems;
    }
    
    public void removeItem(Item item){
       for(int i =0; i< this._items.length;i++){
            if(this._items.equals(item)){
                this._items[i] = null;
                return;
            }
        }
    }
    
    public void displayItem(){
        System.out.println("This customer name is "
        +this._name + "they have "+ this._items.length + " items");
        for(int i =0; i< this._items.length;i++){
            System.out.println("In the array item "+ (i+1)+":"+this._items[i].toString());
        } 
    }
    
    public double calcTotal(){
        double cost = 0;
        for(int i =0; i< this._items.length;i++){
            cost+= this._items[i].getCost();
        }  
        return cost;
    }
    
    public boolean equals(Item[] items){
        int flag =0;
        for(int i =0; i< this._items.length;i++){
            if(this._items[i].getCost() == items[i].getCost() 
            && this._items[i].getName().equals(items[i].getName())){
                flag++;
            }
        }  
        if(flag == this._items.length-1){
            return true;
        }
        return false;
    }
    
    public String toString(){
        return "This is customor " + this._name
        + ". They have " + this._items.length + "items!";
    }

  
}
