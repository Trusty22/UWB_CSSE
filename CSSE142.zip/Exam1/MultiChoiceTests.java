import java.util.*;
/**
 * Write a description of class MultiChoiceTests here.
 *
 * Mandeep Masoun 
 * Apr 18
 */
public class MultiChoiceTests
{
   public static void main(String args[]){
       Scanner sc = new Scanner(System.in);
       //System.out.println(6000%2==0);
       int a = 1;
       int b =1;
       int c = 1;
       int d = 4;;
       int e = 3;
       
       switch(a){
           case a ==b:
               break;
           case b ==c:
               System.out.print("t");
               break;
           default:
                              System.out.print("f");

               break;
           
       }
      System.out.println( 2.5*5.0 );
               

       
   }
   
   public static void method(){
       
   }
}
