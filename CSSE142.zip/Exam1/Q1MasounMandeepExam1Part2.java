import java.util.*;
/**
 * Write a description of class Q1MasounMandeepExam1Part2 here.
 * 
 * Name: Mandeep Masoun 
 * Student ID#: 2121617
 * Date: Apr 18
 * Prof: Hansel Ong
 * 
 */
public class Q1MasounMandeepExam1Part2
{
    
   public static void main(String args[]){
       final double TAX_RATE = .1025;
       
       String itemName;
       double price;
       double vat;
       Scanner s = new Scanner(System.in);
       System.out.println("Hello what is your name");
       String name = s.nextLine();
       
       System.out.println("Hello "+ name + ". What would you like to order?");
        
       System.out.println("Please tell me the name of the item that you would like to order");
       itemName = s.nextLine();
       
       //asuming that there is no food word lenghth that is smaller than 3
       if(itemName.length() < 3){
          System.out.println("Invalid: Not a real food item. Enter a food with length bigger than 2 ");  
          System.exit(0);
       }
       
       System.out.println("What is the price of the item that you would like to order");
       price = s.nextDouble();
           
       if(price < 0){
              System.out.println("Invalid: Not a real price. Enter a positive price.  ");
              System.exit(0);

       }
       
       vat = CalculateVAT(price, TAX_RATE);
       
       ConcludeTransaction(name,itemName,price,vat);
       
       
   }
   
   public static void ConcludeTransaction(String name, String itemName, double cost, double vat){
       System.out.printf("Hi %s. Your total is (%.2f + %.2f) = $%.2f for %s.%n",
                           name, cost, vat, (cost+vat), itemName);
   }
   
   
   public static double CalculateVAT(double cost, double taxRate){
       return cost*taxRate;
   }
   
}
