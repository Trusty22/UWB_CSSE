
/**
 * Write a description of class Lab1a here.
 * Discover bugs
 * @author Madneep Masoun
 * @version (a version number or a date)
 */
  // Lab1a.java
  // This short class has several bugs for practice.
  // Authors: Carol Zander, Rob Nash, Clark Olson, Mandeep Masoun
  public class Lab1a {
    public static void main(String[] args) {
      compareNumbers();
      calculateDistance();
    }

    public static void compareNumbers() {
      int firstNum = 5;
      int secondNum = 5;
      System.out.println( "Sum is: " + (firstNum + secondNum));
      System.out.println( "Difference is: " + (firstNum - secondNum) );
      System.out.println( "Product is: " + firstNum * secondNum );
    }

    public static void calculateDistance() {
      int velocity = 10; //miles-per-hour
      int time = 2, //hoursint
      distance = velocity * time; 
      System.out.println( "Total distance is: "+  distance);
    }
  }
          /*Scanner scanner = new Scanner(System.in);
        System.out.println("Enter");
        
        String newLine = scanner.nextLine();
        System.out.println("Name is"+ newLine);*/

