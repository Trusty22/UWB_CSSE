
/**
 * Write a description of class Tests here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tests
{
    // instance variables - replace the example below with your own
    
    public Tests()
    {
        // initialise instance variables
    
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void sampleMethod()
    {
        // put your code here
        
    }
}
