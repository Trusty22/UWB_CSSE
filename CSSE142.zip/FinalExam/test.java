
/**
 * Write a description of class test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class test
{
    public static void main(String args[]){
       /*
        boolean a = true;
        int b = 3;
        int c = -2;
        if((!a)|| (b>c)){
            System.out.println(b==c);
        }else{
            System.out.println(c);
        }
        */
        
       /*int a =0;
       for(int i = 0; i<3; i++){
           a = a+2;
           for(int j = 0; j<4; j++){
           a = a-1;
           }
       }*/
       /*
       int a = -5;
       while(a> 0){
           a = a-1;
           System.out.println(a);
       }
       System.out.println("gb");*/
       
      /* int k = 0, m=5, n=10;
       
       m--;
       ++n;
       k=n*m;
       k+=m;
       
    double[] myDoubles = {0.0, 1.0, 1.5, 2.0, 2.5};
    
    int[] sequence2 = new int[5];
    sequence2 = new int[100];
    System.out.println(k);*/

    int[] d = {1,5,7,-3,-2};
    for(int e : d){
        e = e-1;
        System.out.println(e + " ");
    }


    }
}
