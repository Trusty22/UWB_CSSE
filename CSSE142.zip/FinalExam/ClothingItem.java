
/**
 * Write a description of class ClothingItem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ClothingItem
{
    // instance variables - replace the example below with your own
    private String _type;
    private String _color;

    /**
     * Constructor for objects of class ClothingItem
     */
    public ClothingItem(String type, String color)
    {
        // initialise instance variables
        if(type.length()<2){
            type = "shirt";
        }
        if(type.length()<2){
            type = "red";
        }
    }
    
    public String getType(){
        return this._type;
    }
    public void setType(String type){
         this._type = type;
    }
    
    public String getColor(){
        return this._color;
    }
    public void setColor(String color){
         this._color = color;
    }

    public boolean equals(ClothingItem clothes){
        if(this._type.equals(clothes.getType())){
            return true;    
        }
        return false;
    }
    
    public String toString(){
        return "This is a "+ this._type+ " it is the color " + this._color;
    }
}
