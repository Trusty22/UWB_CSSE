
/**
 * Write a description of class array2ds here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class array2ds
{
    public static void main(String arhs[]){
        
    }
    
    public static void jagA(int[][] jag){
        int rows = jag.length;
        int colum = jag[0].length;
        for(int i = 0; i < jag.length; i++){
            System.out.println(jag[i].length);
        }
        rows +=1;
    }
    
}
