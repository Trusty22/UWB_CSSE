
/**
 * Write a description of class Tempature here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tempature
{
    // instance variables - replace the example below with your own
    private char scale;
    private double temp;
    
    /**
     * Constructor for objects of class Tempature
     */
    public Tempature()
    {
        // initialise instance variables
        this.temp = 0.0;
        this.scale = 'C';
    }
    
    public Tempature(double temp, char scale)
    {
        // initialise instance variables
        this.temp = temp;
        this.scale = scale;
    }
    
    public void setTemp(double temp){
        this.temp = temp;
    }
    
    public void setScale(char scale){
        this.scale = scale;
    }
    
    public void setScaleAndTemp(char scale,double temp){
        this.scale = scale;
        this.temp = temp;
    }
    
    public int compare(){
        if(this.temp < getTempInF()){
            return -1;
        }
        if(this.temp < getTempInC()){
            return -1;
        }
        if(getTempInC() == getTempInF()){
            return 0;
        }
        return 1;
    }
    
    public String toString(){
        double rounded = Math.round(this.temp*100.0)/100.0;
        return rounded + " "+ this.scale;
    }
    
    public double getTempInC(){
        if(!(this.scale == ('c')) || !(this.scale == ('C'))){
            return (5*(this.temp - 32))/9;
        }
        return temp;
    }
    
    public double getTempInF(){
        if(!(this.scale == ('F')) || (this.scale == ('f'))){
            return ((9*this.temp)/5) + 32;
        }
        return temp;
    }
    
}
