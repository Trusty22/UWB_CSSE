/**
 * Write a description of class Lab4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Scanner;
import java.lang.*;

public class Lab4 {
    /**
     * main method (driver) to execute all the method calls properly
     *
     * @param args
     */
    public static void main(String[] args) {
        countGrains();
        powerOfTwo(4);
        numBackward(93838);
        boxMaker();
    }

    /**
     * Calculates the number of grains and prints out the result per lab instructions
     */
    //Do you observe anything unusual in your output when you run your code? Explain, in comments.
    //After doubling 31 times the program acts differntly as it stops doubling and.
    //goes negitive and than goes to 0
    //this is because the variable int has a max number that can be stored
    // after the max number is reached the computor goes haywire and stops 
    //storeing the numbers properly
    public static void countGrains() {
        // declare and initialize your variables first, if any
        int grain = 1;
        int add = 0;
        for(int i = 1; i< 65; i++){
            System.out.println("Day "+ i +" and you got " + grain + 
                " grain(s) of rice for a total of " + add + " grain(s)");
            grain = doubleGrain(grain);
            add += grain;
        }
    }

    public static int doubleGrain(int num){
        return (num+num);
    }

    /**
     * Determines if a number is power of 2 and displays result per lab instructions
     * @param numberInput
     */
    public static void powerOfTwo (int numberInput) {
        int storeing;
        double num;
        double temp;
        int count = 1;
        // declare and initialize your variables first, if any then start writing your code
        // use what we learned in branching exercise if/else statements
        num = numberInput/2.0;
        if((num - (int)(num)) > 0){
            System.out.println(numberInput+" is not a power of 2");
        }else{
            num = numberInput/2.0;
            while(true){ 
                if((num - (int)(num)) > 0){
                    temp = Math.pow(2,count-1);
                    if(temp == numberInput){
                        System.out.println(numberInput+" is 2 to the power of "+ (count-1));
                        break;
                    }
                    System.out.println(numberInput+" is not a power of 2");
                    break;
                }
                temp = Math.pow(2,count);
                System.out.println(num + " "+ count+ " "+temp);
                num = num/2.0;
                count++;
            }
        }      
    }

    /**
     * Reverses the digits of a given integer, i.e. 12345 would become 54321 per lab instructions
     *
     * @param number
     */
    public static void numBackward(int number) {
        String num = number + "";
        String temp = num;
        String finalNum = "";
        //0 not valid for 
        //0 1 2 3
        //30
        for(int i = 0; i < num.length(); i++){
            temp = temp.substring(temp.length()-1);
            finalNum += temp;
            temp = num.substring(0,num.length()-(1+i));
        }

        if(finalNum.equals(num)){
            System.out.println("backward: "+ finalNum+", palindrome!"); 
        }else{
            System.out.println("backward: "+ finalNum+", not palindrome!"); 
        }
    }

    /**
     * void method that asks the user for an integer x (using Scanner), and prints box using asterisks
     * refer to detailed instructions in lab description part 6
     */
    public static void boxMaker() {
        // declare and initialize your variables first, if any then start writing your code
        int lengths;
        int j;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter box length/height: ");
        lengths = sc.nextInt();

        line(lengths);
        spaces(lengths);
        line(lengths);
    }

    /**
     * Produces and displays a straight line using asterisks per lab instructions
     */
    public static void line(int size){
        for(int i = 0; i < size; i++){
            System.out.print("*");
        }
    }

        public static void StraightLine(int size){
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                System.out.print("*");
            }
            System.out.println("");
        }
    }
    
    public static void spaces(int lengths){
        for(int i = 0; i < lengths; i++){
            System.out.println("");
            System.out.print("*");
            for(int j = 0; j < lengths - 2; j++){
                System.out.print(" ");
            }
            System.out.print("*");
        } 
        System.out.println("");
    }

    /**
     *  void mathod to print a shape that is a triangular pattern with sides of 6 asterisks
     *  refer to detailed instructions in lab description part 7a
     */

    public static void shape7a(int number) {

        // declare and initialize your variables first, if any then start writing your code


    }

    /**
     * void method to print a shape that is an "X" pattern with arms of 3 asterisks each.
     * refer to detailed instructions in lab description part 7b
     */
    public static void shape7b(int number) {

        // declare and initialize your variables first, if any then start writing your code


    }

} // end class Lab4