
/**
 * Write a description of class Driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Driver
{
    public static void main(String args[]){
    
        Item bread0 = new Item("bread", 3.99);
        Item bread1 = new Item("bread", 3.99);
        Item bread2 = new Item("bread", 3.99);
        Item bread3 = new Item("bread", 3.99);
        Item bread4 = new Item("bread", 3.99);
        Item bread5 = new Item("bread", 3.99);
        Item bread6 = new Item("bread", 3.99);
        Item bread7 = new Item("bread", 3.99);
        Item bread8 = new Item("bread", 3.99);
        Item bread9 = new Item("bread", 3.99);
        Item bread10 = new Item("bread", 3.99);
        Customer Alex = new Customer("Alex");
        CheckoutLine line = new CheckoutLine();
        
        Alex.addItem(bread0);
        Alex.addItem(bread1);
        Alex.addItem(bread2);
        Alex.addItem(bread3);
        Alex.addItem(bread4);
        Alex.addItem(bread5);
        Alex.addItem(bread6);
        Alex.addItem(bread7);
        Alex.addItem(bread8);
        Alex.addItem(bread9);
        Alex.addItem(bread10);
    }
    
    public static void positive(){
        
    }
}

