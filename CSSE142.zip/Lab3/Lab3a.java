import java.util.*;
/*
 * Lab3a.java
 *
 * Parts 1 and 2
 *
 * Authors: Samantha Smith, mandeep
 */

public class Lab3a {
    public static void main(String[] args) {
        // oddEvenChecker tests
        System.out.println("\nTesting oddEvenChecker:");
        oddEvenChecker (3); // Should print "3 is an odd number "
        oddEvenChecker (8); // Should print "8 is an even number "
        //TODO: add tests

        // multipleOfChecker tests
        System.out.println("\nTesting multipleOfChecker:");
        multipleOfChecker (16 , 4); // Should Print "16 is a multiple of 4"
        multipleOfChecker (11 , 3); // Should Print "11 is not a multiple of 3"
        //TODO: add tests

        // sqrtSumBucketer tests
        System.out.println("\nTesting sqrtSumBucketer:");
        // TODO: Declare input
        Scanner input = new Scanner(System.in);

        sqrtSumBucketer(input);
    }

    /**
     * oddEvenChecker
     *
     * Determine if num is odd or even.
     *
     * @param	num 	int	The integer to check
     */
    // TODO: You figure out the declaration and the method!
    public static void oddEvenChecker(int num1){
        if(num1 % 2 == 0){
            System.out.println(num1 + " is an even");
        }else{
            System.out.println(num1 + " is an odd");      
        }
    
    }
    /**
     * multipleOfChecker
     *
     * Determine is num is a multiple of base.
     *
     * @param	num		int	The integer to check
     * @param	base	int	The integer base against which to check
     */
    // TODO: You figure out the declaration and the method!
    
    public static void multipleOfChecker(int num1, int num2){
        if(num1 % num2 == 0){
            System.out.println(num1+" is a multipule of "+ num2);      
        }else{
            System.out.println(num1+" is not a multipule of "+ num2);      
        }
        
    }
    
    /**
     * sumSqrtBucketer
     *
     * @param	sc	Scanner	This is used to request user input
     */
    public static void sqrtSumBucketer(Scanner sc){
        double num1;
        double num2;
        double sumOfSqrt;
        
            System.out.println("Please Enter the first num to sqrt and add to the second num");      
            num1 = sc.nextDouble();
            num1 = isNegitive(num1, sc);
            System.out.println("Please Enter the second num to sqrt and add to the first num");      
            num2 = sc.nextDouble();
            num2 = isNegitive(num2, sc);

        
        sumOfSqrt = Math.sqrt(num1) + Math.sqrt(num2);
        if(sumOfSqrt < 10){
            System.out.printf("%.2f is less than 10\n",sumOfSqrt);      
            
        }else if(sumOfSqrt >= 10 && sumOfSqrt <= 20){
            System.out.printf("%.2f is between 10 nd 20\n",sumOfSqrt);      

        }else if(sumOfSqrt > 20 && sumOfSqrt <= 30){
            System.out.printf("%.2f is between 20 and 30\n",sumOfSqrt);      
            
        }else if(sumOfSqrt > 30){
            System.out.printf("%.2f is greater than 30\n",sumOfSqrt);
        }
    
    }
      public static double isNegitive(double num, Scanner sc){
        
        while(num < 0){
            if(num < 0){
                System.out.println("Invalid: number must be greater than 0");
                num = sc.nextDouble();
            }
        }
        return num;
    }
}
