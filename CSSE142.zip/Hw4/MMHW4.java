import java.util.*;
/**
 * Write a description of class MMHW4 here.
 *
 * Mandeep
 * 1.0
 */
public class MMHW4
{
    //java -jar /Users/mandeepmasoun/Desktop/My\ Folders/Code/Jars/HW4-AppsList.jar 

    public static void main(String[] args){
        int numberOfApps;
        String[] appsStored;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("How many apps do you want to track? ");
        numberOfApps = sc.nextInt();
        
        appsStored = new String[numberOfApps];
        //fills array with apps of users want
        for (int i = 0; i < numberOfApps; i++){
            System.out.println("What is the name of app # "+(i+1)+"?");
            appsStored[i] = sc.next();
            System.out.println(appsStored[i]);
        }
        
        
        findLongestApp(appsStored);
        findShortestApp(appsStored);
    }
    public static void findLongestApp(String[] appsStored){
        String compare;
        String finalApp ="";
        for (int i = 0; i < appsStored.length-1; i++){
            if(appsStored[i].length() > appsStored[i+1].length()){
                compare = appsStored[i];
            }else{
                compare = appsStored[i+1];
            }
            if(finalApp.length() < compare.length()){
                finalApp = compare;
            }            
        }
        System.out.println("Longest app name is: "+finalApp);
    }
    
    public static void findShortestApp(String[] appsStored){
        String compare;
        String finalApp = appsStored[0];
        for (int i = 0; i < appsStored.length-1; i++){
            if(appsStored[i].length() < appsStored[i+1].length()){
                compare = appsStored[i];
            }else{
                compare = appsStored[i+1];
            }
            if(finalApp.length() > compare.length()){
                finalApp = compare;
            }            
        }
        System.out.println("Shortest app name is: "+finalApp);
    }
}
