
/**
 * Write a description of class l here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Room
{
    // instance variables - replace the example below with your own
   private Person[][] _seats;

    /**
     * Constructor for objects of class l
     */
    public Room()
    {
        _seats = new Person[10][10];
        
    }
    
    public void seatPerson(Person person){
        int count = 0;
        int colCount =0;
        for(int i = 0; i< _seats.length; i++){
           for(int j = 0; j< _seats[i].length; j++){
               if(this._seats[i][j] != null){
                   count++;
                   colCount++;
                   this._seats[count][colCount] = person;
               }
            }
        }
    }
    
    public void removeP(Person p){
         for(int i = 0; i< _seats.length; i++){
           for(int j = 0; j< _seats[i].length; j++){
              if(this._seats[i][j].equals(p)){
                  this._seats[i][j] = null;
              }
            }
        }
    }
    public String toString(){
        String s="";
        for(int i = 0; i< _seats.length; i++){
           for(int j = 0; j< _seats[i].length; j++){
              s += this._seats[i][j].getName() +"";
            }
            s+="\n";
        }
        return s;
    }

    
}
