/**
 * Write a description of class MMDriver here.
 *
 * Mandeep Masoun
 * May 15
 */
public class MMDriver
{
    // instance variables - replace the example below with your own
    public static void main(String[] args){
        positive();
        negitive();
        boundery();
    }
    /**
     * f# = friend#
     */
    public static void positive(){
        //create 6 instances
        MMPerson f1 = new MMPerson("Jeff");
        MMPerson f2 = new MMPerson("Samantha");
        MMPerson f3 = new MMPerson("Mandeep");
        MMPerson f4 = new MMPerson("Justin");
        MMPerson f5 = new MMPerson("Thomas");
        MMPerson f6 = new MMPerson("Arthur");
        
        //friend to add to all 6
        MMPerson f7 = new MMPerson("Johnny");

        //several friends in f1
        f1.addFriend(f7);
        f1.addFriend(f2);
        f1.addFriend(f3);
        f1.addFriend(f4);
        System.out.println();

        //1 friend for each Person
        f2.addFriend(f7);
        f3.addFriend(f7);
        f4.addFriend(f7);
        f5.addFriend(f7);
        f6.addFriend(f7);

        //remove friend
        System.out.println();
        f1.removeFriend(f7);
        System.out.println();

        // list all friends
        f1.listFriends();
        System.out.println();
        f2.listFriends();
        System.out.println();
        f3.listFriends();
        System.out.println();
        f4.listFriends();
        System.out.println();
        f5.listFriends();
        System.out.println();
        f6.listFriends();
        System.out.println();
        f7.listFriends();
        System.out.println();
        
    }
    public static void negitive(){
        //add friend with no name empty
        MMPerson f1 = new MMPerson("");     
        
        //add to self
        MMPerson f2 = new MMPerson("AppleMan");  
        f2.addFriend(f2);
        
        //add an already added friend
        MMPerson f3 = new MMPerson("Inder");
        MMPerson f4 = new MMPerson("Johnny");
        f3.addFriend(f4);
        f3.addFriend(f4);
        
        // remove friend when not in array
        MMPerson f5 = new MMPerson("Manny"); 
        MMPerson f6 = new MMPerson("Sonny"); 
        f5.addFriend(f6);
        
        f5.removeFriend(f6);
        f5.removeFriend(f6);
    }
    public static void boundery(){
        // Remove a friend from a person who has one friend 
        MMPerson f1 = new MMPerson("Tom");     
        MMPerson f2 = new MMPerson("Billy");  
        f1.addFriend(f2);
        
        f1.removeFriend(f2);
        
        //Attempt to add a friend to a Person whose friend list is “full” 
        MMPerson f3 = new MMPerson("Johnny");  
        
        MMPerson f4 = new MMPerson("Jeff");
        MMPerson f5 = new MMPerson("Samantha");
        MMPerson f6 = new MMPerson("Mandeep");
        MMPerson f7 = new MMPerson("Justin");
        MMPerson f8 = new MMPerson("Thomas");
        MMPerson f9 = new MMPerson("Arthur");
        
        f3.addFriend(f4);
        f3.addFriend(f5);
        f3.addFriend(f6);
        f3.addFriend(f7);
        f3.addFriend(f8);
        f3.addFriend(f9);
        //Print the list of friends from a Person whose friend list is “full” 
        f3.listFriends();
    }
}