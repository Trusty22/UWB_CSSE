/**
 * GiftCard.java
 * CSS142
 * 
 * Skeleton file for a basic giftcard class; useful to set, report, and
 * manage deductions
 */
public class GiftCard {
    //todo: class-level instance variables go here
    // should be double
    private double currentBalance;
    // Constructor
    public GiftCard(double currentBalance) {
        this.currentBalance = currentBalance;
        //System.out.println("Gift card created, current balance: $"+ this.currentBalance);
        
    }
    public GiftCard() {
        this.currentBalance = 0;
         //System.out.println("Gift card created, current balance: $"+ this.currentBalance);
    }
     
    //an example method that needs instance data to be declared first
    public void resetToZero() {
        currentBalance = 0;
        System.out.println("resetter to zero: " + currentBalance + "\n");
    }
    
    public void setBalance(double currentBalance){
        if(currentBalance > 0){
            this.currentBalance = currentBalance;
        }else{
            System.out.println("Can't have negitive balance: Will not deduct.");
            return;
        }
    }
    
    public void deduct(double deduct){
        if(currentBalance - deduct > 0){
            this.currentBalance = currentBalance - deduct;
        }else{
            System.out.println("Can't have negitive balance: Will not deduct.");
            return;
        }
    }
    public void report(){
        System.out.println("$"+this.currentBalance);
    }
    
    public static void main(String[] args) {
        
        //card 1 shows standerd setting
        //card 2 shows deduction in negitive
        //card 3 shows how the constructor is used.
        GiftCard card1 = new GiftCard();
        // the balence is set for card1 50
        card1.setBalance(50);
        // than the balance is printed  50    
        System.out.print("card1 value is :");
        card1.report();
        
        GiftCard card2 = new GiftCard();
        // balance is set for card2 100
        card2.setBalance(100);
        //than card2 is printed 100
        System.out.print("card2 value is :");
        card2.report();
        // card2 balance is deducted -1
        card2.deduct(101);
        System.out.println(" After deducting $101, card2's new balance is :");
        card2.report();
        // card2 prints -1
        card1.deduct(12.50); 
        // card1 balance is now 37.5
        System.out.println(" After deducting $12.50, card1's new balance is :");
        card1.report();
        // prints 37.5
        
        //resets and reports balance at 0 card1
        card1.resetToZero();
        card1.report();
        card2.resetToZero();
        card2.report();
        //resets and reports balance at 0 card2
        
        // User defined constructor
        // sets balance to 5000
        GiftCard card3 = new GiftCard(5000);
        System.out.println("\nSetting the new balance to 7500.99 ");
        //sets new balance
        card3.setBalance(7500.99);
    }
}