
/**
 * Write a description of class test3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class test3
{
       public static void main(String[] args){
        s(7);
        }
        public static void s(int s){
            int n = 7;
            if(s == n){
                System.out.println("ye");
            }else if(s<7){
                 System.out.println("up");
            }else{
                System.out.println("yeno");
                
            }
        }

}
