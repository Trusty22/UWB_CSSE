import java.util.Scanner;
import java.util.*;

/**
 * Write a description of class ShiftNumbers here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ShiftNumbers
{
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter an integer, then press Enter");
        int N = keyboard.nextInt();
        
        // 1. Create your array dynamically here
        int[][] digits = new int[N][N];
        int[][] t = new int[N][N]; 
        int[] temp = new int[digits.length];
        
        for(int j = 0; j < temp.length; j++) {
            temp[j] = j+1;
        }
        
        
        for(int i = 0; i < temp.length; i++){
            for(int j = 0; j < temp.length; j++){
                    digits[i][j] = temp[j];
            }
            rotateLeft(temp);
        }
        
        
        printLine(digits);
        for(int i = 0; i < temp.length; i++){
             for(int j = 0; j < temp.length; j++){
                 System.out.print("|"+digits[i][j]);
             }
             System.out.print("|");
             printLine(digits);   
        }
    }   
    
    public static int[] rotateLeft(int[] digits) {
        int[] array = digits;
        int temp = array[0];    
        
        for(int i = 0; i < array.length-1; i++){ 
            array[i] = array[i+1];
        }
        
        array[array.length-1] = temp;
        //System.out.println(Arrays.toString(array));
        return array;
    }
    
    public static void printLine(int[][] digits){
         System.out.println();
         for(int j = 0; j < digits[0].length; ++j) {
            System.out.print("+-");
        }
        System.out.println("+");  
    }
}