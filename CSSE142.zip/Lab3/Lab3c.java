import java.util.*;
/*
 * Lab3c.java
 *
 * Parts 5
 *
 * Author: Samantha Smith, you
 */

public class Lab3c {
    public static void main(String[] args) {
       Random rn = new Random();
       int rand = rn.nextInt(3);
       Scanner sc = new Scanner(System.in);
        // TODO: Get user choice
       System.out.println("Lets play Rock,Paper,Scissors. Please choose!\nRock = 0\nPaper = 1\nScissors = 2 ");
        // TODO: Generate random computer choice
        int choice = sc.nextInt();
        String myC = intToWord(choice);
        String comC = intToWord(rand);
        while(myC.equals("Invalid Input")){
            System.out.println("Invalid Input, Try again.");
            choice = sc.nextInt();
            myC = intToWord(choice);
        }
        
        System.out.println("You chose "+myC+"! I Choose "+comC+"!");
        // TODO: Print choices
        System.out.println(findWinner(choice, rand));
        // TODO: Determine winner
    }

    /**
     * intToWord
     *
     * Convert from an integer to the relevant string, using a switch
     *
     * @param    choice    int        The choice to convert
     * @return    TODO
     */
    // TODO: You figure out the declaration and the method!
    public static String intToWord(int choice){
        switch(choice){
            case 0:
                return "Rock";
            case 1:
                return "Paper";
            case 2:
                return "Scissors";
            default:
                return "Invalid Input";
                
        }
    }

    /**
     * score
     *
     * Determine the winner from two choices
     *
     * @param    userchoice    int    The user's choice
     * @param    compchoice    int    The computer's choice
     * @return    TODO
     */
    // TODO: You figure out the declaration and the method!
    public static String findWinner(int userChoice, int compChoice){
        //0-rock, 1-paper, 2-scissors
        if((userChoice==0&&compChoice==1)||(userChoice==1&&compChoice==2)||(userChoice==2 &&compChoice==0)){
            return compChoice + " beats "+ userChoice + ". I win.";   
        }
        
        if((userChoice==1&&compChoice==0)||(userChoice==2&&compChoice==1)||(userChoice==0&&compChoice==2)){
            return userChoice + " beats "+ compChoice + ". I win.";   
        }
        return "Tie";
    }

}
