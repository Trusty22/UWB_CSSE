import java.util.*;
/**
 * Write a description of class test6 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class test6
{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int user = sc.nextInt(); 
        
        for(int i = 5; user > 0; i-- ){
            System.out.println(astrik(i));
        }
        
        user = sc.nextInt();
        for(int i = 0; i <= user; i++ ){
            if(i % 2 == 0){
                System.out.println(i);
            }
        }
        
    }
    public static String astrik(int num){
        String line="";
        
        for(int i = 0; i < num; i++){
            line+="*";
        }
        return line;
    }
    
}
