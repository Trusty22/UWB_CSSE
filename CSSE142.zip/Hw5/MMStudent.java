
/**
 * Write a description of class MMStudent here.
 *
 * Mandeep Masoun Student class
 */
public class MMStudent
{
    private String _name;
    private int[] _scores;

    /**
     * Constructor for objects of class MMStudent
     */
    public MMStudent(String name, int maxNumOfAssginments)
    {
        // initialise instance variables
        // learn about invariments 
        this._name = name;
        if(maxNumOfAssginments <= 0){
            maxNumOfAssginments = 1;
            System.out.println("To small: minimum size set to 1");
        }
        if(name.length() < 2){
            System.out.println("Name has to be greater than 1 character: Default set to Tom");
            this._name = "Tom";
        }
        _scores = new int[maxNumOfAssginments];
        
        for(int i = 0; i < maxNumOfAssginments ; i++ ){
            _scores[i] = -1;
        }

    }

    public String getName(){
        return this._name;
    }

    private void setName(String name){
        this._name = name;
    }

    public void viewAssignmentScores(){
        
        if(this._scores.length == 0){
            System.out.print("Array is Empty");
        }
        for(int i = 0; i < this._scores.length; i++ ){
            if(_scores[i] != -1){
                System.out.println("For index "+i+" the value "+_scores[i]+" is being stored");
            }else{
                 System.out.println("For index "+i+" array is empty");
            }
        }
        //this._scores[];
    }

    public void reportNewAssignmentScore(int score){
        score = checkScore(score);
        for(int i = 0; i < this._scores.length; i++ ){
            if(this._scores[i] == -1){
                this._scores[i]= score;
                System.out.println("Slot "+ i+ " is open "+score+ " was inserted ");
                break;
            }
            if(i == this._scores.length-1){
                System.out.println("No open slots to insert a new score!");
            }
        }
        if(this._scores.length == 0){
            System.out.println("There are no spaces to insert as the array is empty.");
        }

    }

    public void updateAssignmentScore(int i, int newScore){
        newScore = checkScore(newScore);
        if(i < 0){
            System.out.println("Index invalid: less than 0. "
            +"This score does not exist. Not updated ");
            i = 0;
            newScore = this._scores[0];
        }
        if(this._scores.length < i){
            System.out.println("Index invalid: Greater than array length. "
            +"This score does not exist. Not updated ");
            i = 0;
            newScore = this._scores[0];
        }
        if(this._scores[i] == -1){
            System.out.println("At index "+ i +" the score "
            + "is empty please report a score first\n");
            return;
        }
        this._scores[i] = newScore;
        System.out.println("Updated! At index "+ i +" the score "
        + this._scores[i]+ " is now being stored\n");
    }
    
    public int checkScore(int score){
        if(score < 0 || score > 100){
            System.out.println("Error score invalid: Has to be between 0 and 100.\nDefault Set to 50");
            return 50;
        }
        return score;
    }
}
