
/**
 * A simple representaion of a toothbrush
 *
 * Mandeep,Css 142 
 * Spring 2022
 */
public class ToothBrush
{
    // pett --> problem solving, enginering, tools, terminology
    //preoperties of object aka: instance variables
    private String typeOfB;
    private int size;
    private String typeOfToothBrush;
    private String color;
    private String brand;
    private boolean isBatteryPowered;
    
    
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Allows user to use the instance to brush their teeth
     */
    public ToothBrush()
    {
        // initialise instance variables
        x = 0;
    }
    /**
     * Allows user to use the instance to brush their teeth
     */
    public void brushTeath(){
       //apply paste
       applyPaste();
       //apply water
       //brush tooths
    }
    
    private void applyPaste(){
    // steps to apply paste
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
