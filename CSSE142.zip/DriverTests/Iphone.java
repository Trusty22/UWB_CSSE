
/**
 * Write a description of class driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Iphone
{
    // instance variables - replace the example below with your own
    private String _color = "blue";
    private String _make = "11 pro";

    /**
     * Constructor for objects of class driver
     */
    public Iphone(String color, String make)
    {
        // initialise instance variables
        this._color = color;
        this._make = make;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return  y;
    }
}
