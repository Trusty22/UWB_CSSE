import java.util.*;
/**
 * Write a description of class conditional here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class conditional
{
   public static void main(String[] args){
       Scanner userInput = new Scanner(System.in);
       
       System.out.print("Give us a number: ");
       int firstNum = userInput.nextInt();
       
       System.out.print("Give us a second number: ");
       int secNum = userInput.nextInt();
       
       if(firstNum < secNum){
       System.out.print(firstNum+ " is smaller than " +secNum);

       }else if(firstNum > secNum){
       System.out.print(firstNum+ " is greater than " +secNum);

       }else{
       System.out.print("the 2 nums are =");
           
       }
 
 
   }
}
