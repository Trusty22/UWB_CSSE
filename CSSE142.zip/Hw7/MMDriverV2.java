/**
 * Write a description of class MMDriver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MMDriverV2
{
    /**
     * Constructor for objects of class MMDriver
     */
    public static void main(String[] args){
        // initialise instance variables
        positive();
        negitive();
        boundery();
    }
    public static void positive(){
        MMPersonV2 p1 = new MMPersonV2("Alex");
        MMPersonV2 p2 = new MMPersonV2("Nick");
        p1.addFriend(p2);
        
        p1.addFriend("Mandeep");
                
        p1.removeFriend(p2);
        p1.removeFriend("Mandeep");
        
        p1.listFriends();
        p2.listFriends();
    }
    public static void negitive(){
        MMPersonV2 p1 = new MMPersonV2("Alex");
        p1.addFriend(p1);
        p1.addFriend("Mandeep");
        p1.addFriend("Mandeep");
    
        MMPersonV2 p2 = new MMPersonV2("J");
        
        p1.addFriend(p2);
        p1.removeFriend(p2);
        p1.removeFriend(p2);
        
        MMPersonV2 p3 = new MMPersonV2("Jeffery");
        p1.addFriend(p3);
        p1.addFriend(p3);
        
    }
    public static void boundery(){
        MMPersonV2 p1 = new MMPersonV2("Alex");
        MMPersonV2 p2 = new MMPersonV2("Joe");
        p1.addFriend(p2);    
        p1.removeFriend(p2);
        
        p1.addFriend("Josh");
        p1.addFriend("Bob");
        p1.addFriend("Mandeep");
        p1.addFriend("Lebron");
        p1.addFriend("Curry");
        p1.addFriend("Jordan");
        
    }
}