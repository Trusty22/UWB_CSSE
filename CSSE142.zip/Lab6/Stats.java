
//necessary imports for file i/o
import java.io.FileInputStream; //"turns" the file into a read stream
import java.util.Scanner; //reads from stream
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream; //"turns" the file into a write stream
import java.io.PrintWriter; //writes to the stream

import java.io.FileNotFoundException; //this exception must be caught and handled when dealing with streams!

/**
 * Write a description of class Stats here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Stats {
    public static void main(String[] args) throws IOException{  
        // Scanner and PrintWrite must be declared outside the try block
        // otherwise their scope will be limited to within the block 
        Scanner input = null;
        
        double inputNumber = 0.0;
        
        int negNum = 0;
        int btw0and100 = 0;
        int geq100 = 0;
        
        int lineCounter = 0;
        double grandTotal = 0.0;
        
        double min = 0.0;
        double max = 0.0;
        double average = 0.0;
        
        
        
        try {            
           input = new Scanner(new FileInputStream("fileIn.txt")); 
           average = average(input);
           
           input = new Scanner(new FileInputStream("fileIn.txt"));
           min = min(input);
           
           input = new Scanner(new FileInputStream("fileIn.txt"));
           max = max(input);
           
           input = new Scanner(new FileInputStream("fileIn.txt"));
           negNum = negNum(input);           

           input = new Scanner(new FileInputStream("fileIn.txt"));
           geq100 = geq100(input);
           
           input = new Scanner(new FileInputStream("fileIn.txt"));
           btw0and100 = btw0and100(input);
        } 
        catch (IOException e) {
           System.out.println("File not found.");
           System.exit(0);
        } 
 
        input.close();   
        display(average, max, min, lineCounter, negNum, btw0and100, geq100);
    }
    
    public static int negNum(Scanner sc){
        int negNum = 0;
        double temp = 0.0;
        while(sc.hasNextDouble()){
            temp = sc.nextDouble();
            if(temp < 0){
                negNum++;
            }
        }
        System.out.println(negNum);
        return negNum;
    }
    
    public static int btw0and100(Scanner sc){
        int btw0and100 = 0;
        double temp = 0.0;
        while(sc.hasNextDouble()){
            temp = sc.nextDouble();
            if(temp >= 0 && temp < 100){
                btw0and100++;
            }
        }
        System.out.println(btw0and100);
        return btw0and100;
    }
    
    public static int geq100(Scanner sc){
        int geq100 = 0;
        double temp = 0.0;
        while(sc.hasNextDouble()){
            temp = sc.nextDouble();
            if(temp >= 100){
                geq100++;
            }
        }
        System.out.println(geq100);
        return geq100;
    }
    
    
    
    public static double min(Scanner sc){
        double min = 0.0;
        double temp = 0.0;
        while(sc.hasNextDouble()){
            temp = sc.nextDouble();
            if(min > temp){
                min = temp;
            }
        }
        System.out.println(min);
        return min;
    }
    
    public static double max(Scanner sc){
        double max = sc.nextDouble();
        double temp = 0.0;
        while(sc.hasNextDouble()){
            temp = sc.nextDouble();
            if(max < temp){
                max = temp;
            }
        }
        System.out.println(max);
        return max;
    }
    
    
    public static double average(Scanner sc){
        double average = 0.0;
        double count = 0.0;
        
        while(sc.hasNextDouble()){
            count++;
            average += sc.nextDouble();
        }
        System.out.println(average/count);
        return average/count;
    }
    
    public static void display (double average, double max, double min, double lineCounter, int negNum, int btw0and100, int geq100){
    
        PrintWriter output = null;
        try{
            output = new PrintWriter(new FileOutputStream("fileOut.txt"));
            output.println("Statistics for the numbers in fileIn.txt:\naverage: "
            + average +"\nmax: "+max+"\nmin: "+min+"\n");
            
            output.println("There are "+negNum+" negative numbers, "+btw0and100+
            " numbers between 0 (inclusive) and 100 (exclusive), and "
            +geq100+" numbers that are greater than or equal to 100.");
        } catch (IOException e) {
            System.out.println(" Sorry, we cannot locate the file!");
            System.exit(0);
        }  
        output.close();
    }
}
