import java.util.*;
/**
 * Write a description of class Arrays here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Arrays
{
    public static void main(String[] args){
     Scanner s = new Scanner(System.in);
     int array[] = new int[3];
     int arr[] = {1,2,3};
     
     String Arr[] = new String[5];
     
     boolean sc[] = new boolean[4];
     
     array = new int[] {1,2,3};
     
     Arr = new String[] {"apple","orange","apple","orange","apple"};
     
     sc = new boolean[] {true,false,false,true};
     
     System.out.println(sc);
     // arr[] =  {0,1,2};
    }
}