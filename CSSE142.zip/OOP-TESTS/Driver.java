
/**
 * Write a description of class Driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Driver{
    public static void main(String[] args){
        
        Soap mySoap = new Soap(5,"a",true);
        
        //System.out.println(mySoap._size);
        
       
        
    }
}
