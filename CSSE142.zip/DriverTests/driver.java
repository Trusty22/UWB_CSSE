
/**
 * Write a description of class driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class driver
{
    // instance variables - replace the example below with your own
    public static void main(String args[]){
        Iphone apple = new Iphone("red","13 pro max");
        
        
    }
}