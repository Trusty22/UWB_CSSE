import java.util.Scanner;
/**
 * Write a description of class test2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class test2{
    public static void main(String[] args){
        //int a =
        multi5(99);
        // System.out.println((a < 100) && (!(a == 66) || (a == 77)));
        // System.out.println(multi5());
    }
    
    public static int multi5(int s){ 
       // Scanner sc = new Scanner(System.in);
       // System.out.println("Enter # to multi by 5: ");
        int userInput = s;//c.nextInt() * 5 ;  
        
        return s;//userInput;
    }
}
// do you want comments?