import java.util.*;
/**
 * Write a description of class Hw1Mandeep here.
 *
 * @Mandeep Masoun
 * Told by Professor Ong that comments are not required 
 */
public class HW1_Masoun{
    public static Scanner userInput = new Scanner(System.in);

    public static void main(String[] args){
        int userOptions;
        int currentCost;
        int currentBudget;
        
        displayFoods();
        System.out.print("Please choose from the above options: ");
        
        userOptions = userInput.nextInt();
         if(userOptions > 4 || userOptions < 0){    
            System.out.println("This Not a Valid Option choose from 1-4");
            System.exit(0);
        }
        System.out.print("What is the current cost of the item: ");
        currentCost = userInput.nextInt();
        
        if (currentCost < 0){
            while(true){
                System.out.print("Please choose a positve number: ");
                currentCost = userInput.nextInt();
                if(currentCost > 0){
                    break;
                }
            }
        }
        System.out.print("What is your current budget for this item: ");
        currentBudget = userInput.nextInt();
        
        if (currentBudget < currentCost){                                 
            while(true){
                System.out.print("Please choose a buget greater or equal than your cost: ");
                currentBudget = userInput.nextInt();
                if(currentBudget >= currentCost){
                    break;
                }
            }
        }
        
        inflationAndAffordability(currentCost,currentBudget);
        
    }
    public static void displayFoods(){
        System.out.println("1. Bread (per loaf)\n2. Milk (per gallon)\n"
                    + "3. Meat (per pound)\n4. Vegetables (per pound)");
                    
    }
    public static void inflationAndAffordability(int cost, int budget){
         int amountYouCanBuy = budget/cost;
         double inflation = 1.05 * cost;
         
         System.out.println("Your currently able to purchace: "
         + amountYouCanBuy + " units");
         
         System.out.println("Next year you can purchace "
         + (int)(budget/inflation) + " units");
         
         System.out.println("The year after you can purchace "
         + (int)(budget/(inflation * 1.05)) + " units"); 
    }
}
