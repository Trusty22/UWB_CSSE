import java.util.*;
/**
 * Write a description of class Q1MasounMandeepExam1Part2 here.
 *
 * Name: Mandeep Masoun 
 * Student ID#: 2121617
 * Date: Apr 18
 * Prof: Hansel Ong
 * 
 */
public class Q2MasounMandeepExam1Part2
{
    
   public static void main(String args[]){
       
       
   }
   
   public static void supplyAndDemand(double supply, double demand){
       if(supply < 0){
           System.out.println("Invalid Input!");
           return;
       }
       if(demand < 0){
            System.out.println("Invalid Input!");
           return;
       }
      
     
       
       if((supply  * .1) >= demand ){
          System.out.println("Low demand. Perhaps lower the price?"); 
       }else if((supply  * .25) <= demand && (supply  * .75) >= demand ){
           System.out.println("About the right level of supply vs. demand");
       } else if((supply  * .9) <= demand  ){
           System.out.println("Very high demand.  Perhaps increase the price?");
       }else if (demand > supply ){
           System.out.println("We have a shortage. Definitely increase the price.");
       }
         if(supply > demand){
           System.out.println("Demand is currently "+ (demand / supply * 100)+ "% of supply");
       }
       
    }
}
