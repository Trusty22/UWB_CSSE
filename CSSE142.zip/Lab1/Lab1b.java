
/**
 * Write a description of class Lab1b here.
 * lab 1: it's about the basics of coding methods and print statements
 * @author Mandeep Masoun
 * @version (a version number or a date)
 */
  // Lab1b.java
  // This is a practice lab to output a few verses of
  //"99 bottles of beer on the wall"
  // Authors: Carol Zander, Clark Olson, Mandeep
  
public class Lab1b {
     public static void main (String[] args) {
        int numBottles;  // number of bottles currently on the wall
        
        // display first verse
        numBottles = 5;
        System.out.print(numBottles);
        onWall();
        System.out.print(numBottles);
        botBeer();
        takeOneDown();
        numBottles = 4;
        System.out.print(numBottles);
        onWall();
        System.out.println();  // display blank line between verses

        // display second verse
        numBottles = 4;
        System.out.print(numBottles);
        onWall();
        System.out.print(numBottles);
        botBeer();
        takeOneDown();
        numBottles = 3;
        System.out.print(numBottles);
        onWall();
        System.out.println();
        
        // display third verse
        numBottles = 3;
        System.out.print(numBottles);
        onWall();
        System.out.print(numBottles);
        botBeer();
        takeOneDown();
        numBottles = 2;
        System.out.print(numBottles);
        onWall();
        System.out.println();
        
        // display fourth verse
        numBottles = 2;
        System.out.print(numBottles);
        onWall();
        System.out.print(numBottles);
        botBeer();
        oneBottleFall();
        numBottles = 1;
        System.out.print(numBottles);
        oneOnWall();
        System.out.println();
         
        // display fifth verse
        numBottles = 1;
        System.out.print(numBottles);
        oneOnWall();
        System.out.print(numBottles);
        oneBotBeer();
        takeitDown();
        System.out.print("No more");
        onWall();
        System.out.println();
     }

     public static void onWall() {
        System.out.println(" bottles of root beer on the wall");
     }
     
      public static void oneOnWall() {
        System.out.println(" bottle of root beer on the wall");
     }

     public static void botBeer() {
        System.out.println(" bottles of root beer");
     }
    
      public static void oneBotBeer() {
        System.out.println(" bottle of root beer");
     }
    
     public static void takeOneDown() {
        System.out.println("Take one down and pass it around");
     }
     
     public static void takeitDown() {
        System.out.println("Take it down and pass it around");
     }
     
     public static void oneBottleFall() {
        System.out.println("If one of those bottles should happen to fall");
     }
  }
