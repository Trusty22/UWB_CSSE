
/**
 * Write a description of class CheckoutLine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CheckoutLine
{
    // instance variables - replace the example below with your own
    private Customer[] _customers;

    /**
     * Constructor for objects of class CheckoutLine
     */
    public CheckoutLine()
    {
        this._customers = new Customer[99];        
        
    }
    public void queCust(Customer c){
        for(int i = 0; i< this._customers.length; i++){
            if(this._customers[i] == null){
                this._customers[i] = c;
            }
        }
    }
    public void serveCust(Customer c){
        Customer[] temp = new Customer[this._customers.length];
        int count = 0;
        if(this._customers[0] == null){
            System.out.println("No customers to serve!");
            return;
        }
        this._customers[0] = null;
        for(int i = 0; i< this._customers.length; i++){
            if(this._customers[i] != null){
                temp[count] = this._customers[i];
                count++;
            }
        }
        System.out.println();
    }
    public String toString(){
        String s = "This is the line\n";
        for(int i = 0; i< this._customers.length; i++){
            s += this._customers[i].toString() + "\n";
        }
        return s;
    }
    
    
}
