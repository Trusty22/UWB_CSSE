
/**
 * Write a description of class Tests2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tests2
{
    // instance variables - replace the example below with your own
    public Tests2()
    {
        // initialise instance variables
    
    }
    
    public static void main(String args[]){
        for(int i = 3; (i>3)&&(1<10);i = i+2){
            System.out.print(i);
            i=i-1;
            i = 20/i;
         
        }
    }

    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void sampleMethod()
    {
        // put your code here
        
    }
}
//6