
/**
 * Write a description of class Competitor here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Competitor
{
    // instance variables - replace the example below with your own
    private String _name;
    private int _topScore;
    private int[] _scores;
    
    /**
     * Constructor for objects of class Student
     */
    public Competitor(String name, int firstScore )
    {
        // initialise instance variables
        this._scores = new int[5];
        this._topScore = firstScore;
        if(name.length() < 2){
            this._name = "Alex";
        }else{
            this._name = name;
        }
        for(int i = 0; i < _scores.length-1; i++){
            this._scores[i]=-1;
        }
        if(firstScore < 0 || firstScore > 100){
            this._scores[0] = 0;
        }else{
            this._scores[0] = this._topScore;
        }        
    }

    public void newScore(int score){
        if(this._topScore < score ){
            this._topScore = score;
        }
        for(int i = 0; i < this._scores.length; i++){
            if(this._scores[i]==-1){
                this._scores[i] = score;
                return;
            }
        }
        System.out.println("Error: scores list filled, last index of the array will now be the score you gave");
        this._scores[this._scores.length] = score;
    }
    public String getName(){
        return this._name;
    }
    
    public int getTopScore(){
        return this._topScore;
    }

}
